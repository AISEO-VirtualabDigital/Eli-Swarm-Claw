# Virtualabdigital — Design Instructions

Source-of-truth design spec for this brand. Use alongside `tokens.json`, the CSS files and the brand guide PDF. Every rule below is binding — break it only with intent.

_Generated 2026-08-04._

---

## 01. Palette

| Role | Name | Hex |
| --- | --- | --- |
| primary | Primary | `#0A0A0A` |
| background | Background | `#F4EFE6` |
| accent | Accent | `#8B1A1A` |
| text | Text | `#5F5A52` |
| muted | Muted | `#D8D0C3` |

**Rules**

- Use color roles (`primary`, `accent`, `surface`, `ink`…) — never the hex directly in product code.
- One accent per surface. Reserve the most saturated value for primary CTAs and errors.
- Maintain WCAG AA contrast (4.5:1 body, 3:1 large text). Verify pairings before shipping.

## 01a. Contrast — WCAG rules (binding)

These pairings are computed from the palette above using the WCAG 2.1 contrast formula.
**An AI / designer / engineer using this kit MUST obey them verbatim. Never invent a pairing not listed as ✅ here.**

**Thresholds**

- `AAA` ≥ 7.0:1 — required for body copy at small sizes when possible.
- `AA`  ≥ 4.5:1 — minimum for body copy under 18pt / 14pt bold.
- `AA Large` ≥ 3.0:1 — only valid for text ≥ 24px (or ≥ 18.66px bold), large icons, focus rings.
- `FAIL` < 3.0:1 — **never use for text or meaningful UI** under any circumstance.

**Decision rule (apply in order)**

1. If a pairing is `FAIL`, do not use it for text, icons, borders carrying meaning, or focus states. Decorative fills only.
2. If a pairing is `AA Large`, use it only for text ≥ 24px regular / ≥ 18.66px bold, or for non-text UI (icons, focus rings).
3. Prefer `AAA` for any body copy. Fall back to `AA` only when palette constraints force it.
4. When in doubt, use the highest-ratio pairing the design will allow — **never** pick a lower one because it 'looks nicer'.

**Pairing matrix** (foreground × background)

| Foreground | Background | Ratio | Verdict | Allowed for |
| --- | --- | --- | --- | --- |
| `primary` (#0A0A0A) | `background` (#F4EFE6) | 17.29:1 | AAA ✅ | Body, headings, icons, all UI |
| `primary` (#0A0A0A) | `accent` (#8B1A1A) | 2.13:1 | FAIL ❌ | **Decoration only — never text or meaningful UI** |
| `primary` (#0A0A0A) | `text` (#5F5A52) | 2.90:1 | FAIL ❌ | **Decoration only — never text or meaningful UI** |
| `primary` (#0A0A0A) | `muted` (#D8D0C3) | 12.94:1 | AAA ✅ | Body, headings, icons, all UI |
| `primary` (#0A0A0A) | `white` (#FFFFFF) | 19.80:1 | AAA ✅ | Body, headings, icons, all UI |
| `primary` (#0A0A0A) | `black` (#000000) | 1.06:1 | FAIL ❌ | **Decoration only — never text or meaningful UI** |
| `background` (#F4EFE6) | `primary` (#0A0A0A) | 17.29:1 | AAA ✅ | Body, headings, icons, all UI |
| `background` (#F4EFE6) | `accent` (#8B1A1A) | 8.11:1 | AAA ✅ | Body, headings, icons, all UI |
| `background` (#F4EFE6) | `text` (#5F5A52) | 5.97:1 | AA ✅ | Body copy, headings, icons |
| `background` (#F4EFE6) | `muted` (#D8D0C3) | 1.34:1 | FAIL ❌ | **Decoration only — never text or meaningful UI** |
| `background` (#F4EFE6) | `white` (#FFFFFF) | 1.15:1 | FAIL ❌ | **Decoration only — never text or meaningful UI** |
| `background` (#F4EFE6) | `black` (#000000) | 18.34:1 | AAA ✅ | Body, headings, icons, all UI |
| `accent` (#8B1A1A) | `primary` (#0A0A0A) | 2.13:1 | FAIL ❌ | **Decoration only — never text or meaningful UI** |
| `accent` (#8B1A1A) | `background` (#F4EFE6) | 8.11:1 | AAA ✅ | Body, headings, icons, all UI |
| `accent` (#8B1A1A) | `text` (#5F5A52) | 1.36:1 | FAIL ❌ | **Decoration only — never text or meaningful UI** |
| `accent` (#8B1A1A) | `muted` (#D8D0C3) | 6.07:1 | AA ✅ | Body copy, headings, icons |
| `accent` (#8B1A1A) | `white` (#FFFFFF) | 9.29:1 | AAA ✅ | Body, headings, icons, all UI |
| `accent` (#8B1A1A) | `black` (#000000) | 2.26:1 | FAIL ❌ | **Decoration only — never text or meaningful UI** |
| `text` (#5F5A52) | `primary` (#0A0A0A) | 2.90:1 | FAIL ❌ | **Decoration only — never text or meaningful UI** |
| `text` (#5F5A52) | `background` (#F4EFE6) | 5.97:1 | AA ✅ | Body copy, headings, icons |
| `text` (#5F5A52) | `accent` (#8B1A1A) | 1.36:1 | FAIL ❌ | **Decoration only — never text or meaningful UI** |
| `text` (#5F5A52) | `muted` (#D8D0C3) | 4.47:1 | AA Large ⚠️ | Large text only (≥24px), focus rings, large icons |
| `text` (#5F5A52) | `white` (#FFFFFF) | 6.84:1 | AA ✅ | Body copy, headings, icons |
| `text` (#5F5A52) | `black` (#000000) | 3.07:1 | AA Large ⚠️ | Large text only (≥24px), focus rings, large icons |
| `muted` (#D8D0C3) | `primary` (#0A0A0A) | 12.94:1 | AAA ✅ | Body, headings, icons, all UI |
| `muted` (#D8D0C3) | `background` (#F4EFE6) | 1.34:1 | FAIL ❌ | **Decoration only — never text or meaningful UI** |
| `muted` (#D8D0C3) | `accent` (#8B1A1A) | 6.07:1 | AA ✅ | Body copy, headings, icons |
| `muted` (#D8D0C3) | `text` (#5F5A52) | 4.47:1 | AA Large ⚠️ | Large text only (≥24px), focus rings, large icons |
| `muted` (#D8D0C3) | `white` (#FFFFFF) | 1.53:1 | FAIL ❌ | **Decoration only — never text or meaningful UI** |
| `muted` (#D8D0C3) | `black` (#000000) | 13.73:1 | AAA ✅ | Body, headings, icons, all UI |
| `white` (#FFFFFF) | `primary` (#0A0A0A) | 19.80:1 | AAA ✅ | Body, headings, icons, all UI |
| `white` (#FFFFFF) | `background` (#F4EFE6) | 1.15:1 | FAIL ❌ | **Decoration only — never text or meaningful UI** |
| `white` (#FFFFFF) | `accent` (#8B1A1A) | 9.29:1 | AAA ✅ | Body, headings, icons, all UI |
| `white` (#FFFFFF) | `text` (#5F5A52) | 6.84:1 | AA ✅ | Body copy, headings, icons |
| `white` (#FFFFFF) | `muted` (#D8D0C3) | 1.53:1 | FAIL ❌ | **Decoration only — never text or meaningful UI** |
| `white` (#FFFFFF) | `black` (#000000) | 21.00:1 | AAA ✅ | Body, headings, icons, all UI |
| `black` (#000000) | `primary` (#0A0A0A) | 1.06:1 | FAIL ❌ | **Decoration only — never text or meaningful UI** |
| `black` (#000000) | `background` (#F4EFE6) | 18.34:1 | AAA ✅ | Body, headings, icons, all UI |
| `black` (#000000) | `accent` (#8B1A1A) | 2.26:1 | FAIL ❌ | **Decoration only — never text or meaningful UI** |
| `black` (#000000) | `text` (#5F5A52) | 3.07:1 | AA Large ⚠️ | Large text only (≥24px), focus rings, large icons |
| `black` (#000000) | `muted` (#D8D0C3) | 13.73:1 | AAA ✅ | Body, headings, icons, all UI |
| `black` (#000000) | `white` (#FFFFFF) | 21.00:1 | AAA ✅ | Body, headings, icons, all UI |

**Forbidden pairings (do not use for text or UI):**

- **NEVER** place `primary` (#0A0A0A) text on `accent` (#8B1A1A) — ratio 2.13:1.
- **NEVER** place `primary` (#0A0A0A) text on `text` (#5F5A52) — ratio 2.90:1.
- **NEVER** place `primary` (#0A0A0A) text on `black` (#000000) — ratio 1.06:1.
- **NEVER** place `background` (#F4EFE6) text on `muted` (#D8D0C3) — ratio 1.34:1.
- **NEVER** place `background` (#F4EFE6) text on `white` (#FFFFFF) — ratio 1.15:1.
- **NEVER** place `accent` (#8B1A1A) text on `text` (#5F5A52) — ratio 1.36:1.
- **NEVER** place `accent` (#8B1A1A) text on `black` (#000000) — ratio 2.26:1.
- **NEVER** place `muted` (#D8D0C3) text on `white` (#FFFFFF) — ratio 1.53:1.

## 02. Typography

| Role | Family | Weights | License |
| --- | --- | --- | --- |
| heading | DMSans | 400, 700 | unknown |
| body | DMSans | 400 | unknown |

**Rules**

- Respect role assignments. Display faces are not body faces.
- Set heading line-height ~1.05–1.15. Body 1.45–1.6. Mono / labels uppercase tracked +60–120.
- Substitute fonts are open-source stand-ins. Original commercial fonts must be licensed before production use.

## 03. Voice

Virtualabdigital brand kit extracted from virtualabdigital.com.

**Tone**

- clear (60%)
- direct (55%)

**Vocabulary**

Virtualabdigital, virtualabdigital.com, brand, system

**Do**

- Keep language direct
- Use concise calls to action

**Don't**

- Avoid vague claims
- Do not overstate unsupported details

**Sample copy**

- _cta_: Explore the system
- _headline_: Virtualabdigital, clearly defined
- _email intro_: A concise look at Virtualabdigital.
- _slide title_: Virtualabdigital identity

## 04. Tokens

### spacing

| Name | Value |
| --- | --- |
| `base` | `8px` |

### radius

| Name | Value |
| --- | --- |
| `default` | `8px` |

### shadow

| Name | Value |
| --- | --- |
| `soft` | `0 16px 40px rgba(0,0,0,0.10)` |

### animation

| Name | Value |
| --- | --- |
| `standard` | `200ms ease` |

## 05. Usage

- `tokens.json` (W3C Design Tokens) is the canonical machine-readable source.
- `*.css` ships CSS custom properties; `*-tailwind.css` ships a Tailwind v4 `@theme` block.
- `*-tokens-studio.json` imports into Figma via the Tokens Studio plugin.
- `fonts/` holds open-licensed font files. `FONTS.md` documents licensing.
- `assets/` holds extracted logos and brand imagery.
- `brand-guide.pdf` is the print-ready editorial guide.
