# Fonts in this kit

This file documents every typeface in your brand kit, where it came from, and what license applies.

**Read before shipping:** Fonts marked **COMMERCIAL** require a license from their foundry. We do **not** include the original font files for those — only an open-source substitute close in feel. Buy or license the original before using it in production.

---

## DMSans — _heading_

- License: **UNKNOWN**
- Provider: unknown
- Weights: 400, 700
- Files: 3 detected. Files NOT bundled (license restricted).

## DMSans — _body_

- License: **UNKNOWN**
- Provider: unknown
- Weights: 400
- Files: 3 detected. Files NOT bundled (license restricted).
