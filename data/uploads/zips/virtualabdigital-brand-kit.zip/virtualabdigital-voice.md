# Virtualabdigital — Brand Voice

Virtualabdigital brand kit extracted from virtualabdigital.com.

## Tone

- clear (60%)
- direct (55%)

## Vocabulary

Virtualabdigital, virtualabdigital.com, brand, system

## Do

- Keep language direct
- Use concise calls to action

## Don't

- Avoid vague claims
- Do not overstate unsupported details

## Sample copy

**cta**: Explore the system

**headline**: Virtualabdigital, clearly defined

**email intro**: A concise look at Virtualabdigital.

**slide title**: Virtualabdigital identity
