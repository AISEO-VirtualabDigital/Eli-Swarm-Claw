# Orange Orbit → Agent Eli Migration Map

| Orange Orbit capability | Agent Eli destination |
|---|---|
| FastAPI application | Eli Core API |
| Owner token authentication | Security / operator authentication |
| OpenRouter client | Model Router |
| Knowledge store | Knowledge Vault + RAG |
| Memory create/search/forget | Persistent Memory |
| Crew registry | Agent / Crew Registry |
| Director and specialists | Skills and specialist agents |
| PostgreSQL | Structured state |
| Redis | Queue, cache and jobs |
| Docker deployment | Infrastructure |
| Safe mode | Policy engine |
| Manual learning feed | Knowledge intake approval |
| Collab / Connect | Integration registry |
| Missions | Workflow and task engine |

An untouched Orange Orbit archive should be retained before production migration.
