# Implementation Roadmap

## Phase 1 — Foundation
- Preserve Orange Orbit archive
- Move owner authentication into Eli Core
- Migrate memory and knowledge
- Add integration and skill registries
- Add policy engine and audit logging
- Build Baserow-inspired workspace

## Phase 2 — First-party SEO intelligence
- SiteOne adapter
- Search Console and GA4 adapters
- Content decay
- Cannibalization
- Local recon
- AI citation monitoring
- White-label parasite strategy
- Authority link acquisition

## Phase 3 — Execution
- n8n workflows
- WordPress staging
- outreach staging
- reports and deliverables
- approval queue
- verification jobs

## Phase 4 — Persistent knowledge
- Obsidian vault
- Google Drive ingestion
- source-of-truth rules
- semantic retrieval
- provenance and version history
