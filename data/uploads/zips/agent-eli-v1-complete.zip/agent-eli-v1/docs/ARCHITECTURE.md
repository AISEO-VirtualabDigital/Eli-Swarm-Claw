# Agent Eli Architecture

## Public layer

- Portfolio
- Work
- Agent Eli
- Systems
- Skills
- Services
- Case studies
- Contact

The operator portrait and professional identity belong in the public viewer experience, not inside the private dashboard.

## Private layer

- Dashboard
- Leads
- Audits
- Campaigns
- Content Engine
- Rank Tracking
- Approvals
- Activity Logs
- Integrations
- Workflows
- Sentinel Scrapers
- Open SEO Skills
- Crew Registry
- Databases
- Knowledge Vault
- Orange Orbit Legacy
- Settings

## Core runtime

Orange Orbit is preserved as Agent Eli's legacy core:

- FastAPI
- owner authentication
- knowledge search
- memory create/search/forget
- OpenRouter model routing
- crew registry
- PostgreSQL
- Redis
- Docker
- safe mode

## State machine

OBSERVE → ANALYZE → PLAN → PREVIEW → APPROVAL → EXECUTE → VERIFY → RECORD

## Prime directive

The operator is final authority.

Eli does not exist to agree.
Eli exists to make the operator faster without lying.
