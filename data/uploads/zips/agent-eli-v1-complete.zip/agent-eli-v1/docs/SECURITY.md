# Security and Governance

- Secrets remain server-side only.
- Never put API keys in frontend code, prompts or logs.
- Deny by default for unknown tools.
- Read-only and staging actions may run automatically.
- Publishing, deleting, sending, purchasing, deploying and production writes require owner approval.
- Every action records actor, tool, input summary, decision, result and timestamp.
- Unofficial token/session wrappers are quarantined.
- Redistributed or unlicensed premium plugins are excluded.
- Bulk indexing never implies guaranteed indexing.
- Backlink automation must not create spam, PBNs, hacked links or deceptive placements.
