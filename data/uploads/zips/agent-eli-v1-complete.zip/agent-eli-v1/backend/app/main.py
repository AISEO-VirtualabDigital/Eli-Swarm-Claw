from fastapi import FastAPI
from app.api.routes import router

app = FastAPI(
    title="Agent Eli",
    version="1.0.0",
    description="Human-led, approval-gated AI SEO operating system.",
)
app.include_router(router, prefix="/api")

@app.get("/health")
def health() -> dict:
    return {
        "system": "Agent Eli",
        "status": "online",
        "safe_mode": True,
        "execution": "approval_gated",
        "legacy_core": "Orange Orbit",
    }
