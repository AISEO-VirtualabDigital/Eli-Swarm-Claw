from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from app.core.policy import evaluate_action
from app.services.registry import load_integrations, load_skills

router = APIRouter()

class ActionRequest(BaseModel):
    action: str
    resource: str
    production: bool = False
    destructive: bool = False

@router.get("/status")
def status():
    return {
        "safe_mode": True,
        "state_model": ["OBSERVE","ANALYZE","PLAN","PREVIEW","APPROVAL","EXECUTE","VERIFY","RECORD"],
        "production_writes": "blocked_without_owner_approval",
    }

@router.get("/integrations")
def integrations():
    return load_integrations()

@router.get("/skills")
def skills():
    return load_skills()

@router.post("/policy/evaluate")
def policy_evaluate(payload: ActionRequest):
    return evaluate_action(payload.model_dump())

@router.post("/execute")
def execute(payload: ActionRequest):
    decision = evaluate_action(payload.model_dump())
    if not decision["allowed"]:
        raise HTTPException(status_code=403, detail=decision)
    return {"ok": True, "state": "STAGED", "decision": decision}
