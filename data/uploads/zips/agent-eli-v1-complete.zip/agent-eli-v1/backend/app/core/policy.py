HIGH_RISK_ACTIONS = {
    "publish", "delete", "send_email", "send_message", "change_budget",
    "deploy", "bulk_submit", "modify_production", "purchase", "create_user"
}

def evaluate_action(request: dict) -> dict:
    action = request.get("action", "").lower()
    production = bool(request.get("production"))
    destructive = bool(request.get("destructive"))
    requires_approval = production or destructive or action in HIGH_RISK_ACTIONS
    return {
        "allowed": not requires_approval,
        "requires_owner_approval": requires_approval,
        "safe_mode": True,
        "reason": "Owner approval required for production, destructive or external side-effect actions."
        if requires_approval else "Read-only or staging action permitted.",
    }
