from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[3]

def _load(folder: str) -> list[dict]:
    items = []
    for path in sorted((ROOT / "registry" / folder).glob("*.json")):
        items.append(json.loads(path.read_text()))
    return items

def load_integrations() -> list[dict]:
    return _load("integrations")

def load_skills() -> list[dict]:
    return _load("skills")
