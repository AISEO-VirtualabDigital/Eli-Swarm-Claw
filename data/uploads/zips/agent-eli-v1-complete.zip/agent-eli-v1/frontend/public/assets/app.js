
const integrations = [
 {id:'baserow',name:'Baserow / Postgres',cat:'Data & CRM',icon:'DB',desc:'Structured operational data, trackers and campaign records.',status:'Connected',auth:'API token / database DSN',caps:['read records','create records','update records','schema discovery','sync jobs']},
 {id:'n8n',name:'n8n Workflows',cat:'Automation',icon:'WF',desc:'Deterministic automation, routing, schedules and webhooks.',status:'Connected',auth:'API key / webhook',caps:['run workflow','inspect execution','schedule jobs','pause workflow']},
 {id:'openrouter',name:'OpenRouter / LLM',cat:'AI & Intelligence',icon:'AI',desc:'Multi-model analysis and controlled provider routing.',status:'Connected',auth:'API key',caps:['chat','reasoning','model fallback','budget routing']},
 {id:'siteone',name:'SiteOne Crawler',cat:'Scrapers',icon:'SC',desc:'Deep technical SEO, security, accessibility and performance crawling.',status:'Available',auth:'Self-hosted',caps:['JS crawl','technical SEO','screenshots','security audit','JSON export']},
 {id:'sentinel',name:'Sentinel Scrapers',cat:'Scrapers',icon:'SN',desc:'SERP, Maps, Reddit, forum, competitor and AI citation reconnaissance.',status:'Available',auth:'Adapter based',caps:['SERP recon','maps scan','forum scan','citation monitor']},
 {id:'gsc',name:'Google Search Console',cat:'Data & CRM',icon:'GS',desc:'Queries, pages, clicks, impressions and indexing signals.',status:'Available',auth:'OAuth',caps:['performance data','URL inspection','sitemaps']},
 {id:'ga4',name:'Google Analytics 4',cat:'Data & CRM',icon:'GA',desc:'Traffic, events, conversions and user-path analysis.',status:'Available',auth:'OAuth',caps:['events','conversions','funnels','audiences']},
 {id:'wordpress',name:'WordPress',cat:'Web & Hosting',icon:'WP',desc:'Content staging, schema, pages and approved publishing.',status:'Available',auth:'Application password / REST',caps:['draft post','update page','media','schema','publish with approval']},
 {id:'drive',name:'Google Drive',cat:'Knowledge',icon:'GD',desc:'Client documents, deliverables and approved source material.',status:'Available',auth:'OAuth / service account',caps:['search','read','export','folder sync']},
 {id:'obsidian',name:'Obsidian Vault',cat:'Knowledge',icon:'OV',desc:'Persistent operator knowledge, SOPs, decisions and project memory.',status:'Planned',auth:'Local filesystem / MCP',caps:['semantic search','link graph','project memory']},
 {id:'dataforseo',name:'DataForSEO',cat:'SEO Data',icon:'DF',desc:'Paid SERP, keyword, competitor and local search datasets.',status:'Available',auth:'API credentials',caps:['SERP data','keywords','rankings','local data']},
 {id:'custom',name:'Custom REST / MCP',cat:'Custom',icon:'+',desc:'Connect any future tool using REST, webhook, MCP, Python or local scripts.',status:'Open',auth:'Configurable',caps:['custom actions','custom auth','webhooks','MCP tools']}
];

function renderIntegrations(filter='All Systems'){
 const el=document.getElementById('integrationGrid');
 const q=(document.getElementById('integrationSearch')?.value||'').toLowerCase();
 el.innerHTML=integrations.filter(i=>(filter==='All Systems'||i.cat===filter) && (i.name.toLowerCase().includes(q)||i.desc.toLowerCase().includes(q))).map(i=>`
 <div class="integration" data-id="${i.id}">
   <div class="integration-icon">${i.icon}</div><h4>${i.name}</h4><p>${i.desc}</p>
   <div class="integration-footer"><span><span class="status-dot"></span> ${i.status}</span><span>Manage →</span></div>
 </div>`).join('');
 document.querySelectorAll('.integration').forEach(c=>c.onclick=()=>openIntegration(c.dataset.id));
}
function openIntegration(id){
 const i=integrations.find(x=>x.id===id); if(!i)return;
 document.getElementById('modalTitle').textContent=i.name;
 document.getElementById('modalBody').innerHTML=`
 <p>${i.desc}</p><div class="metrics" style="grid-template-columns:repeat(3,1fr)">
 <div class="metric"><small>Status</small><b style="font-size:16px">${i.status}</b></div>
 <div class="metric"><small>Category</small><b style="font-size:16px">${i.cat}</b></div>
 <div class="metric"><small>Authentication</small><b style="font-size:13px">${i.auth}</b></div></div>
 <h4>Capabilities</h4><div class="capabilities">${i.caps.map(x=>`<span>${x}</span>`).join('')}</div>
 <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:22px">
 <button class="btn">Test Connection</button><button class="btn">Configure</button><button class="btn primary">Open Tool</button></div>`;
 document.getElementById('modal').classList.add('open');
}
document.addEventListener('DOMContentLoaded',()=>{
 renderIntegrations();
 document.getElementById('modalClose').onclick=()=>document.getElementById('modal').classList.remove('open');
 document.getElementById('modal').onclick=e=>{if(e.target.id==='modal')e.currentTarget.classList.remove('open')};
 document.querySelectorAll('.tab').forEach(t=>t.onclick=()=>{document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));t.classList.add('active');renderIntegrations(t.dataset.filter)});
 document.getElementById('integrationSearch').oninput=()=>renderIntegrations(document.querySelector('.tab.active').dataset.filter);
 document.querySelectorAll('.navitem[data-view]').forEach(n=>n.onclick=()=>{
   document.querySelectorAll('.navitem').forEach(x=>x.classList.remove('active'));n.classList.add('active');
   document.getElementById('workspaceTitle').textContent=n.dataset.view;
   document.getElementById('workspaceDesc').textContent='Live operator view for '+n.dataset.view.toLowerCase()+'.';
 });
});
