---
id: ctx-001
type: context_snapshot
status: active
project_id: eli-os
task_id: task-001
created_at: 2026-08-01T20:17:00+04:00
---

# CTX-001 — Task Context Snapshot

## Binding Sources

- [[../01-HUMAN-ORDERS/ORDER-001-Phase-1]]
- [[../03-ARCHITECTURE/ADR/ADR-001-Phase-1-Binding-Decisions]]
- [[../03-ARCHITECTURE/Phase-1-Research-Framework]]
- [[../04-SPRINTS/SPRINT-001-Phase-1]]
- [[../05-REPOSITORY/MIGRATION-BOUNDARIES]]
- [[../05-REPOSITORY/PHASE-1-CONFLICT-REPORT]]

## Current Scope

Phase 1, Step 1 only.

## Staleness Rule

This context becomes stale if:
- the human order changes;
- the ADR is superseded;
- migration boundaries change;
- task acceptance criteria change.
