# Tasks

Each task must:
- reference a human order;
- have one active version;
- define scope, inputs, outputs, permissions, and acceptance criteria;
- remain anchored to one agent at a time.
