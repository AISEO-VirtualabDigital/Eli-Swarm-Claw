---
id: skill-006
type: agent_skill
status: approved
authority: binding
version: 1.0.0
---

# Skill 006 — Human Manual Rewiring Compliance

Human manual rewiring overrides automatic workflow composition.

When a human rewires a workflow, the agent must:

- Preserve the new graph
- Record who changed it
- Record why it changed
- Revalidate affected paths
- Mark invalidated outputs stale
- Recalculate dependencies
- Never restore the previous graph without human approval
