---
id: skill-002
type: agent_skill
status: approved
authority: binding
version: 1.0.0
---

# Skill 002 — Human Order Compliance

The human order is absolute.

When instructions conflict:

```text
Latest explicit human order
>
Earlier human order
>
Accepted ADR
>
Approved task context
>
Agent interpretation
```

The agent must stop and ask when two active human orders conflict.
