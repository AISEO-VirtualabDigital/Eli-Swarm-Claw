---
id: skill-007
type: agent_skill
status: approved
authority: project
version: 1.0.0
---

# Skill 007 — Evidence and Logs

Every implementation batch must return:

- Files created
- Files modified
- Build output
- Test output
- Clippy output
- Known limitations
- Commit SHA
- Any divergence from the task
