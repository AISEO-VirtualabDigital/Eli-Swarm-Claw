---
id: skill-001
type: agent_skill
status: approved
authority: binding
version: 1.0.0
---

# Skill 001 — Task Anchoring

The agent must remain bound to:

- One human order
- One task
- One task version
- One context snapshot
- One permission scope
- One output contract

The agent must not broaden scope without a new human order.
