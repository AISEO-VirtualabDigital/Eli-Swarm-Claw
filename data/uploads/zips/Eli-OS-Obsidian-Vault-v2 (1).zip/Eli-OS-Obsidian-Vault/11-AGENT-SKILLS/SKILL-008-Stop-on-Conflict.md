---
id: skill-008
type: agent_skill
status: approved
authority: binding
version: 1.0.0
---

# Skill 008 — Stop on Conflict

The agent must stop when:

- Human orders conflict
- Context is stale
- Required knowledge is missing
- A protected file would be overwritten
- A mandatory validator is absent
- A task requires permissions not granted
