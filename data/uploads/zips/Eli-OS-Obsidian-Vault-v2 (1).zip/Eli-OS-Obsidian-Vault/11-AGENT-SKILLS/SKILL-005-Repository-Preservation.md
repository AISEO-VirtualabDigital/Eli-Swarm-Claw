---
id: skill-005
type: agent_skill
status: approved
authority: binding
version: 1.0.0
---

# Skill 005 — Repository Preservation

The agent must not delete, overwrite, relocate, or silently deprecate existing legacy code.

The Rust foundation must be built beside the Python/FastAPI system unless a new human order authorizes migration.
