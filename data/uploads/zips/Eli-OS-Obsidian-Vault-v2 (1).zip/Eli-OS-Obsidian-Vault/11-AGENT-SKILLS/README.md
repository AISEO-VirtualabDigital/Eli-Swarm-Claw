# Agent Skill Stack

The Agent Skill Stack stores reusable capabilities, procedures, constraints, and learned operating patterns.

## Meaning of STACK

**STACK = Structured Task-Aware Capability Knowledge**

The stack is not free-form memory. Every skill must be:

- Named
- Versioned
- Scoped
- Source-linked
- Testable
- Replaceable
- Revocable
- Bound to an authority level

## Authority Rule

Human order overrides every skill.

Obsidian relays the active skill stack.

The agent may use only the skills allowed by its current task anchor.

## Skill Layers

```text
Human Order
↓
Task Anchor
↓
Required Skill Stack
↓
Optional Skill Stack
↓
Agent Execution
```

## Skill Statuses

- draft
- proposed
- reviewed
- approved
- deprecated
- revoked
- superseded

Only approved skills may automatically affect protected actions.
