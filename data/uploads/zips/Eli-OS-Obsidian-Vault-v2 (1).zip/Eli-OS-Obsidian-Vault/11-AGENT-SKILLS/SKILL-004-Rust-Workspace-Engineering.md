---
id: skill-004
type: agent_skill
status: approved
authority: project
version: 1.0.0
---

# Skill 004 — Rust Workspace Engineering

Use:

- Strongly typed domain models
- No panic paths for external input
- Serde support
- SQLx-compatible types where required
- OpenAPI schema derivation where required
- Unit tests
- `cargo fmt`
- Clippy with warnings denied
- Workspace-level tests
