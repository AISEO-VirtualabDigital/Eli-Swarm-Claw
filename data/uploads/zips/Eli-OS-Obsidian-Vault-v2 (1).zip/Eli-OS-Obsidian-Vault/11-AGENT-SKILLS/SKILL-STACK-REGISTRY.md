---
id: skill-stack-registry
type: skill_registry
status: active
authority: binding
project_id: eli-os
---

# Eli-OS Agent Skill Stack Registry

## STACK Definition

**Structured Task-Aware Capability Knowledge**

## Core Agent Skills

- [[SKILL-001-Task-Anchoring]]
- [[SKILL-002-Human-Order-Compliance]]
- [[SKILL-003-Obsidian-Relay-Reading]]
- [[SKILL-004-Rust-Workspace-Engineering]]
- [[SKILL-005-Repository-Preservation]]
- [[SKILL-006-Manual-Rewiring-Compliance]]
- [[SKILL-007-Evidence-and-Logs]]
- [[SKILL-008-Stop-on-Conflict]]

## Skill Resolution Order

```text
Human explicit instruction
↓
Active task anchor
↓
Approved project skills
↓
Approved global skills
↓
Agent default behavior
```

A lower layer may never override a higher layer.
