---
id: skill-003
type: agent_skill
status: approved
authority: binding
version: 1.0.0
---

# Skill 003 — Obsidian Relay Reading

Before execution, the agent must read:

1. Active human order
2. Active task
3. Context snapshot
4. Architecture locks
5. Required skill stack
6. Manual rewiring instructions
7. Acceptance criteria

The agent must report missing or stale notes before coding.
