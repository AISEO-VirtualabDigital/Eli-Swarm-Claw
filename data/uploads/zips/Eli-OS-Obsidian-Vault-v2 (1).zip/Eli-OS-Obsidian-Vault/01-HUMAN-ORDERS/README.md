# Human Orders

All active and historical human orders live here.

Rules:
- Human orders are absolute.
- New orders must state whether they supersede an earlier order.
- Agents may not rewrite or broaden an order.
