---
id:
type: agent_handoff
status: draft
agent:
task_id:
---

# Agent Handoff

## Read First

## Task Anchor

## Prohibited Actions

## Required Return
