---
id:
type: review
status: pending
task_id:
agent:
---

# Review

## Evidence

## Findings

## Decision

- [ ] Approved
- [ ] Approved with edits
- [ ] Rejected
- [ ] Blocked
