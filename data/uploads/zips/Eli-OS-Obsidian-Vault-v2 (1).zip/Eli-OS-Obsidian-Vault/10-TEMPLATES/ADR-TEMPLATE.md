---
id:
type: architecture_decision
status: proposed
authority: binding
project_id:
date:
---

# ADR

## Context

## Decision

## Alternatives

## Consequences

## Security

## Operations

## Tests
