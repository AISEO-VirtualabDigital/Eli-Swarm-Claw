# Templates

Use these templates for new orders, tasks, ADRs, handoffs, and reviews.
