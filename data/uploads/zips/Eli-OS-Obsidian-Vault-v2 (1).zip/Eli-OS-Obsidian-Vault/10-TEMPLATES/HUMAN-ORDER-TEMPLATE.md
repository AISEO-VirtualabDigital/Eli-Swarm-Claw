---
id:
type: human_order
status: active
authority: absolute
project_id:
task_id:
issued_by: human
issued_at:
supersedes:
---

# Human Order

## Absolute Order

## Scope

## Prohibited Actions

## Required Output
