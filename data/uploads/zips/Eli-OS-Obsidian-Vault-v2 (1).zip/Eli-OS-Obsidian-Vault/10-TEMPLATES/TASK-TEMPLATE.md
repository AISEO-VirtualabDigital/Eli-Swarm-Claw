---
id:
type: task
status: draft
project_id:
order_id:
assigned_agent:
context_snapshot:
---

# Task

## Objective

## Inputs

## Outputs

## Constraints

## Acceptance Criteria
