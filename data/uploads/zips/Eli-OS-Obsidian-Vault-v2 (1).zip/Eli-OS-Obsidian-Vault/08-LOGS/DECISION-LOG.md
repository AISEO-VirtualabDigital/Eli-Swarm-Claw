# Decision Log

Record important human corrections and accepted implementation choices.
