# Eli-OS Changelog

## Unreleased

- Obsidian coordination vault initialized.
