# Phase 1 Conflict Report

## Conflict

Existing implementation is Python/FastAPI.
Phase 1 introduces a Rust workspace.

## Resolution

Build side by side.
Do not replace the legacy system.
Treat the legacy system as the operational reference until migration is explicitly ordered.
