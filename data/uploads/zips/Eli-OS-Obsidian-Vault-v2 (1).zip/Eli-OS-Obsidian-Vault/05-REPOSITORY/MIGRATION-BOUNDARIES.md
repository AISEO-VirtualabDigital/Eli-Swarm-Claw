---
id: migration-boundaries
type: migration_policy
status: binding
project_id: eli-os
---

# Migration Boundaries

## Preserve

- Existing Python/FastAPI application
- Existing Next.js frontend
- Existing Celery workers
- Existing Redis configuration
- Existing database models
- Existing Docker files
- Existing tests

## New Rust Foundation

Preferred location:

```text
eli-os/
├── Cargo.toml
├── crates/
├── apps/
├── proto/
├── migrations/
├── docs/
└── tests/
```

Migration or removal requires a new human order.
