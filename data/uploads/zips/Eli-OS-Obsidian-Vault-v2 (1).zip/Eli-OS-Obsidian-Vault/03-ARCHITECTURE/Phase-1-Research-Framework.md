---
id: phase-1-research
type: architecture_reference
status: reviewed
authority: reference
project_id: eli-os
---

# Eli-OS Phase 1 Research Framework

Paste the final cleaned research framework here.

Binding decisions belong in ADR-001.
