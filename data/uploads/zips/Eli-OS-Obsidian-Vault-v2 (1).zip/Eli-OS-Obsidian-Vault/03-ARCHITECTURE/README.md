# Architecture

Binding architecture decisions and research framework.

Accepted ADRs override research notes.
Superseded ADRs must remain for history.
