# Authority Model

## Absolute Order

```text
HUMAN
↓
OBSIDIAN
↓
AGENT
```

## Rules

- Human gives the order.
- Obsidian relays and versions the message.
- Agent is task-bound.
- Agents may not expand scope.
- Conflicts return to human.
