---
id: rewiring-log
type: workflow_rewiring_log
status: active
project_id: eli-os
---

# Manual Rewiring Log

## Entry Template

### Rewire ID

- Human actor:
- Date:
- Workflow:
- Previous version:
- New version:
- Reason:
- Nodes added:
- Nodes removed:
- Edges added:
- Edges removed:
- Providers replaced:
- Validators added:
- Human approvals added:
- Outputs invalidated:
- Revalidation result:
- Execution approval:
