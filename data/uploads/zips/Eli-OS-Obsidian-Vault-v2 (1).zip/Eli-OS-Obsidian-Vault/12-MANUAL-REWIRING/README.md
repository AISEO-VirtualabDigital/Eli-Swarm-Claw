# Human Manual Rewiring

Human manual rewiring is the highest workflow-control mechanism.

Auto Mode may propose.
The human may rewire.
The system must obey the human-authored graph.

## Manual Rewiring Operations

- Add node
- Remove node
- Replace plugin
- Replace provider
- Connect ports
- Disconnect ports
- Reorder execution
- Insert validator
- Insert human approval
- Pause path
- Disable path
- Create fallback path
- Force manual-only mode
- Restore an earlier graph version
