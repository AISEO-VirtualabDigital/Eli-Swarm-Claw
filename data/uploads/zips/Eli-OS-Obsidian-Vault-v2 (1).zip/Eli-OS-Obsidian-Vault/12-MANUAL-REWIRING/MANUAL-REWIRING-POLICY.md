---
id: manual-rewiring-policy
type: workflow_policy
status: accepted
authority: binding
project_id: eli-os
---

# Human Manual Rewiring Policy

## Absolute Rule

A human-authored workflow graph overrides Auto Mode composition.

## Required Behavior

When manual rewiring occurs:

1. Save the previous graph version.
2. Save the new graph version.
3. Record the human actor.
4. Record the reason.
5. Compute the graph diff.
6. Detect affected nodes and outputs.
7. Mark affected outputs stale.
8. Re-run static DAG validation.
9. Re-check validator dominance.
10. Re-check permissions and side-effect policies.
11. Require human confirmation before executing newly introduced destructive paths.

## Auto Mode Restrictions

Auto Mode may not silently:

- Reconnect removed edges
- Restore replaced providers
- Remove human approval nodes
- Remove validators
- Change protected destinations
- Bypass manual-only nodes
