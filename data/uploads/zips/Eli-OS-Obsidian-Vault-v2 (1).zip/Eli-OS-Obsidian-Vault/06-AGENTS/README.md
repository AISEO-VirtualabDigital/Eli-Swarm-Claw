# Agents

Each agent gets a handoff note, task anchor, outputs, and review status.
