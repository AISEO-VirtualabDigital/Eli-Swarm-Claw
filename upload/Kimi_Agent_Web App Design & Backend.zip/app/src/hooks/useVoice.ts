import { useCallback, useEffect, useRef, useState } from "react";

/* Web Speech API types (not in default TS lib) */
interface SpeechRecognitionResultItem {
  transcript: string;
  confidence: number;
}
interface SpeechRecognitionResult {
  isFinal: boolean;
  [index: number]: SpeechRecognitionResultItem;
}
interface SpeechRecognitionResultList {
  length: number;
  [index: number]: SpeechRecognitionResult;
}
interface SpeechRecognitionEventLike extends Event {
  resultIndex: number;
  results: SpeechRecognitionResultList;
}
interface SpeechRecognitionErrorLike extends Event {
  error: string;
  message?: string;
}
interface SpeechRecognitionLike extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  onresult: ((e: SpeechRecognitionEventLike) => void) | null;
  onerror: ((e: SpeechRecognitionErrorLike) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
  abort: () => void;
}

declare global {
  interface Window {
    SpeechRecognition?: new () => SpeechRecognitionLike;
    webkitSpeechRecognition?: new () => SpeechRecognitionLike;
  }
}

export type VoiceError =
  | "not-allowed"
  | "no-speech"
  | "network"
  | "unsupported"
  | null;

export function useVoice(opts: {
  onFinal: (transcript: string) => void;
  onError?: (err: Exclude<VoiceError, null>) => void;
}) {
  const [listening, setListening] = useState(false);
  const [interim, setInterim] = useState("");
  const [supported] = useState(
    () => typeof window !== "undefined" && !!(window.SpeechRecognition || window.webkitSpeechRecognition)
  );
  const recRef = useRef<SpeechRecognitionLike | null>(null);
  const wantListeningRef = useRef(false);
  const restartTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const onFinalRef = useRef(opts.onFinal);
  const onErrorRef = useRef(opts.onError);
  onFinalRef.current = opts.onFinal;
  onErrorRef.current = opts.onError;

  const stop = useCallback(() => {
    wantListeningRef.current = false;
    if (restartTimerRef.current) clearTimeout(restartTimerRef.current);
    recRef.current?.abort();
    recRef.current = null;
    setListening(false);
    setInterim("");
  }, []);

  const start = useCallback(() => {
    const Ctor = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!Ctor) {
      onErrorRef.current?.("unsupported");
      return;
    }
    stop();

    const rec = new Ctor();
    rec.continuous = true;
    rec.interimResults = true;
    rec.lang = "en-US";

    rec.onresult = (e) => {
      let interimText = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const result = e.results[i];
        if (result.isFinal) {
          const text = result[0].transcript.trim();
          if (text) onFinalRef.current(text);
        } else {
          interimText += result[0].transcript;
        }
      }
      setInterim(interimText);
    };

    rec.onerror = (e) => {
      if (e.error === "not-allowed" || e.error === "service-not-allowed") {
        onErrorRef.current?.("not-allowed");
        stop();
      } else if (e.error === "network") {
        onErrorRef.current?.("network");
      } else if (e.error === "no-speech") {
        onErrorRef.current?.("no-speech");
      }
    };

    rec.onend = () => {
      setInterim("");
      // Debounced restart prevents the rapid-fire race condition from v1
      if (wantListeningRef.current) {
        restartTimerRef.current = setTimeout(() => {
          if (wantListeningRef.current) {
            try {
              rec.start();
            } catch {
              /* already started */
            }
          }
        }, 400);
      } else {
        setListening(false);
      }
    };

    recRef.current = rec;
    wantListeningRef.current = true;
    try {
      rec.start();
      setListening(true);
    } catch {
      onErrorRef.current?.("unsupported");
      stop();
    }
  }, [stop]);

  const toggle = useCallback(() => {
    if (wantListeningRef.current) stop();
    else start();
  }, [start, stop]);

  useEffect(() => () => stop(), [stop]);

  return { listening, interim, supported, start, stop, toggle };
}

/* ------------------------- Eli's voice (TTS output) ----------------------- */

let cachedVoice: SpeechSynthesisVoice | null = null;

function pickVoice(): SpeechSynthesisVoice | null {
  if (cachedVoice) return cachedVoice;
  const voices = window.speechSynthesis?.getVoices() ?? [];
  cachedVoice =
    voices.find((v) => /en[-_]US/i.test(v.lang) && /google|natural|neural/i.test(v.name)) ??
    voices.find((v) => /en[-_]US/i.test(v.lang)) ??
    voices.find((v) => v.lang.startsWith("en")) ??
    voices[0] ??
    null;
  return cachedVoice;
}

export function speak(text: string, opts?: { rate?: number; onEnd?: () => void }) {
  if (typeof window === "undefined" || !window.speechSynthesis) return;
  window.speechSynthesis.cancel();
  const utter = new SpeechSynthesisUtterance(text);
  const voice = pickVoice();
  if (voice) utter.voice = voice;
  utter.rate = opts?.rate ?? 1.02;
  utter.pitch = 0.95;
  if (opts?.onEnd) utter.onend = opts.onEnd;
  window.speechSynthesis.speak(utter);
}

export function stopSpeaking() {
  if (typeof window !== "undefined" && window.speechSynthesis) {
    window.speechSynthesis.cancel();
  }
}

export const ttsSupported = typeof window !== "undefined" && "speechSynthesis" in window;
