import { EliSidebar } from "@/components/eli/EliSidebar";
import { AnalyzerView } from "@/components/eli/views/AnalyzerView";
import { AuditView } from "@/components/eli/views/AuditView";
import { ConsoleView } from "@/components/eli/views/ConsoleView";
import { MissionsView } from "@/components/eli/views/MissionsView";
import { OverviewView } from "@/components/eli/views/OverviewView";
import { SafetyView } from "@/components/eli/views/SafetyView";
import { SchedulesView } from "@/components/eli/views/SchedulesView";
import { SerpView } from "@/components/eli/views/SerpView";
import { VaultView } from "@/components/eli/views/VaultView";
import { LOGIN_PATH } from "@/const";
import { useAuth } from "@/hooks/useAuth";
import { Menu, Sprout } from "lucide-react";
import { useState } from "react";
import { Toaster } from "sonner";

export type EliView =
  | "console"
  | "overview"
  | "missions"
  | "analyzer"
  | "serp"
  | "vault"
  | "schedules"
  | "safety"
  | "audit";

const VIEW_META: Record<EliView, { title: string; subtitle: string }> = {
  console: { title: "Voice Console", subtitle: "Speak or type — Eli plans the mission" },
  overview: { title: "Overview", subtitle: "Your organic growth command center" },
  missions: { title: "Missions", subtitle: "Preview → approve → execute, all persisted" },
  analyzer: { title: "Website Analyzer", subtitle: "Deep on-page SEO scans and full-site crawls" },
  serp: { title: "SERP Scraper", subtitle: "Free live search intelligence and content extraction" },
  vault: { title: "Knowledge Vault", subtitle: "Eli's persistent memory" },
  schedules: { title: "Schedules", subtitle: "Recurring missions on autopilot" },
  safety: { title: "Safety Center", subtitle: "Guardrails that keep growth clean" },
  audit: { title: "Audit Log", subtitle: "The immutable record of everything" },
};

export default function Home() {
  const { user, isLoading, logout } = useAuth();
  const [view, setView] = useState<EliView>("console");
  const [sidebarOpen, setSidebarOpen] = useState(false);

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="orb animate-float flex h-16 w-16 items-center justify-center rounded-3xl">
            <Sprout className="h-8 w-8 text-white" />
          </div>
          <div className="text-sm text-slate-500">Booting Eli OS Core…</div>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="flex min-h-screen items-center justify-center p-6">
        <div className="glass flex max-w-md flex-col items-center gap-6 p-10 text-center">
          <div className="orb animate-float flex h-20 w-20 items-center justify-center rounded-3xl">
            <Sprout className="h-10 w-10 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-white">
              Eli <span className="gradient-text">OS Core</span>
            </h1>
            <p className="mt-2 text-sm leading-relaxed text-slate-400">
              Your voice-controlled organic growth operating system. Sign in to command missions,
              analyze websites, and grow without paid ads.
            </p>
          </div>
          <button onClick={() => (window.location.href = LOGIN_PATH)} className="btn-primary w-full !py-3">
            Sign in with Kimi
          </button>
          <p className="text-[11px] text-slate-600">Organic growth only — no ads, no PPC, ever.</p>
        </div>
      </div>
    );
  }

  const meta = VIEW_META[view];

  return (
    <div className="flex min-h-screen">
      <EliSidebar
        view={view}
        onNavigate={setView}
        user={user}
        onLogout={logout}
        open={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
      />

      <div className="flex min-w-0 flex-1 flex-col">
        {/* Top bar */}
        <header className="sticky top-0 z-30 flex items-center gap-3 border-b border-white/[0.07] bg-[#07070f]/80 px-4 py-3.5 backdrop-blur-xl sm:px-6">
          <button
            onClick={() => setSidebarOpen(true)}
            className="rounded-lg p-2 text-slate-400 hover:bg-white/5 hover:text-white lg:hidden"
          >
            <Menu className="h-5 w-5" />
          </button>
          <div className="min-w-0">
            <h1 className="truncate text-base font-bold tracking-tight text-white">{meta.title}</h1>
            <p className="truncate text-xs text-slate-500">{meta.subtitle}</p>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <span className="chip hidden border-emerald-400/20 bg-emerald-400/[0.07] text-emerald-300 sm:inline-flex">
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" />
              Backend live
            </span>
          </div>
        </header>

        <main key={view} className="animate-fade-up flex-1 p-4 sm:p-6">
          {view === "console" && <ConsoleView />}
          {view === "overview" && <OverviewView onNavigate={setView} />}
          {view === "missions" && <MissionsView />}
          {view === "analyzer" && <AnalyzerView />}
          {view === "serp" && <SerpView />}
          {view === "vault" && <VaultView />}
          {view === "schedules" && <SchedulesView />}
          {view === "safety" && <SafetyView />}
          {view === "audit" && <AuditView />}
        </main>
      </div>

      <Toaster
        theme="dark"
        position="bottom-right"
        toastOptions={{
          style: {
            background: "rgba(15,15,28,0.95)",
            border: "1px solid rgba(255,255,255,0.1)",
            backdropFilter: "blur(12px)",
          },
        }}
      />
    </div>
  );
}
