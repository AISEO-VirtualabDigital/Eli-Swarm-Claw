import { cn } from "@/lib/utils";
import {
  BookOpen,
  CalendarClock,
  Globe,
  LayoutDashboard,
  LogOut,
  Mic,
  Radar,
  ScrollText,
  ShieldCheck,
  Sprout,
  Target,
  X,
} from "lucide-react";
import type { EliView } from "@/pages/Home";

const NAV: { key: EliView; label: string; icon: typeof Mic; hint: string }[] = [
  { key: "console", label: "Voice Console", icon: Mic, hint: "Talk to Eli" },
  { key: "overview", label: "Overview", icon: LayoutDashboard, hint: "Command center" },
  { key: "missions", label: "Missions", icon: Target, hint: "Plans & lifecycle" },
  { key: "analyzer", label: "Website Analyzer", icon: Globe, hint: "SEO deep-scan" },
  { key: "serp", label: "SERP Scraper", icon: Radar, hint: "Free rank intel" },
  { key: "vault", label: "Knowledge Vault", icon: BookOpen, hint: "Eli's memory" },
  { key: "schedules", label: "Schedules", icon: CalendarClock, hint: "Recurring missions" },
  { key: "safety", label: "Safety Center", icon: ShieldCheck, hint: "Guardrails" },
  { key: "audit", label: "Audit Log", icon: ScrollText, hint: "Immutable trail" },
];

export function EliSidebar({
  view,
  onNavigate,
  user,
  onLogout,
  open,
  onClose,
}: {
  view: EliView;
  onNavigate: (v: EliView) => void;
  user: { name?: string | null; email?: string | null } | undefined;
  onLogout: () => void;
  open: boolean;
  onClose: () => void;
}) {
  return (
    <>
      {/* Mobile overlay */}
      {open && (
        <div className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm lg:hidden" onClick={onClose} />
      )}

      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-50 flex w-64 flex-col border-r border-white/[0.07] bg-[#0a0a16]/90 backdrop-blur-2xl transition-transform duration-300 lg:static lg:translate-x-0",
          open ? "translate-x-0" : "-translate-x-full"
        )}
      >
        {/* Logo */}
        <div className="flex items-center justify-between px-5 pb-5 pt-6">
          <div className="flex items-center gap-3">
            <div className="orb flex h-10 w-10 items-center justify-center rounded-2xl">
              <Sprout className="h-5 w-5 text-white" />
            </div>
            <div>
              <div className="text-sm font-bold tracking-tight text-white">Eli OS Core</div>
              <div className="text-[10px] font-medium uppercase tracking-[0.18em] text-slate-500">
                Organic Growth OS
              </div>
            </div>
          </div>
          <button onClick={onClose} className="rounded-lg p-1.5 text-slate-400 hover:bg-white/5 hover:text-white lg:hidden">
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Nav */}
        <nav className="flex-1 space-y-1 overflow-y-auto px-3">
          {NAV.map((item) => {
            const active = view === item.key;
            return (
              <button
                key={item.key}
                onClick={() => {
                  onNavigate(item.key);
                  onClose();
                }}
                className={cn(
                  "group flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left transition-all duration-200",
                  active
                    ? "border border-violet-400/25 bg-violet-500/15 text-white shadow-[0_0_24px_-6px_rgba(139,92,246,0.5)]"
                    : "border border-transparent text-slate-400 hover:bg-white/[0.05] hover:text-slate-200"
                )}
              >
                <item.icon
                  className={cn("h-4 w-4 shrink-0", active ? "text-violet-300" : "text-slate-500 group-hover:text-slate-300")}
                />
                <div className="min-w-0 flex-1">
                  <div className="truncate text-[13px] font-medium">{item.label}</div>
                  <div className={cn("truncate text-[10px]", active ? "text-violet-300/70" : "text-slate-600")}>
                    {item.hint}
                  </div>
                </div>
                {active && <span className="h-1.5 w-1.5 rounded-full bg-violet-300" />}
              </button>
            );
          })}
        </nav>

        {/* Organic badge */}
        <div className="mx-3 mb-3 rounded-xl border border-emerald-400/20 bg-emerald-400/[0.07] px-3 py-2.5">
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-300">
            <Sprout className="h-3.5 w-3.5" />
            Organic Growth Only
          </div>
          <p className="mt-1 text-[10px] leading-relaxed text-emerald-200/50">
            No paid ads. No PPC. Earned growth through SEO, content & authority.
          </p>
        </div>

        {/* User */}
        <div className="flex items-center gap-3 border-t border-white/[0.07] px-4 py-4">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-white/10 bg-gradient-to-br from-violet-500/30 to-cyan-500/30 text-sm font-bold text-white">
            {(user?.name ?? "O").charAt(0).toUpperCase()}
          </div>
          <div className="min-w-0 flex-1">
            <div className="truncate text-xs font-semibold text-white">{user?.name ?? "Operator"}</div>
            <div className="truncate text-[10px] text-slate-500">{user?.email ?? ""}</div>
          </div>
          <button
            onClick={onLogout}
            title="Sign out"
            className="rounded-lg p-2 text-slate-500 transition-colors hover:bg-red-400/10 hover:text-red-300"
          >
            <LogOut className="h-4 w-4" />
          </button>
        </div>
      </aside>
    </>
  );
}
