import { speak, stopSpeaking, ttsSupported, useVoice } from "@/hooks/useVoice";
import { cn } from "@/lib/utils";
import { trpc } from "@/providers/trpc";
import { CornerDownLeft, Mic, MicOff, Send, ShieldAlert, Volume2, VolumeX } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { MissionCard, type MissionRow } from "../MissionPlanCard";
import { GlassPanel } from "../ui";

const SUGGESTIONS = [
  "Audit my site for technical SEO issues",
  "Research keywords for a Dubai dental clinic",
  "Plan a blog post about local SEO for pest control",
  "Build a local SEO strategy for my plumbing business",
  "Create a YouTube growth plan for my channel",
];

const WAVE_HEIGHTS = [14, 22, 32, 26, 38, 30, 20, 34, 24, 16, 28, 36, 22, 14, 26];

export function ConsoleView() {
  const [command, setCommand] = useState("");
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [lastError, setLastError] = useState<string | null>(null);
  const [activeMission, setActiveMission] = useState<MissionRow | null>(null);
  const [transcriptHistory, setTranscriptHistory] = useState<{ text: string; at: Date }[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);
  const utils = trpc.useUtils();

  const preview = trpc.eli.previewMission.useMutation({
    onSuccess: (data) => {
      if (data.mission) setActiveMission(data.mission as MissionRow);
      utils.eli.listMissions.invalidate();
      utils.eli.overview.invalidate();
      utils.eli.listAudit.invalidate();
      if (!data.verdict.allowed) {
        toast.error("Blocked by Safety Engine", { description: data.verdict.reasons[0] });
        if (voiceEnabled) speak("That command is blocked by my safety guardrails.");
      } else if (data.plan) {
        toast.success("Mission plan ready", { description: data.plan.skills.join(" + ") });
        if (voiceEnabled) speak(`Mission ready. I've routed this to ${data.plan.skills.join(" and ")}. Review the plan and approve when ready.`);
      }
    },
    onError: (err) => toast.error("Mission failed", { description: err.message }),
  });

  const approve = trpc.eli.approveMission.useMutation({
    onSuccess: (m) => {
      setActiveMission(m as MissionRow);
      utils.eli.listMissions.invalidate();
      utils.eli.overview.invalidate();
      toast.success("Mission approved");
      if (voiceEnabled) speak("Approved. Ready to execute on your command.");
    },
    onError: (err) => toast.error(err.message),
  });

  const reject = trpc.eli.rejectMission.useMutation({
    onSuccess: (m) => {
      setActiveMission(m as MissionRow);
      utils.eli.listMissions.invalidate();
      utils.eli.overview.invalidate();
      toast("Mission rejected");
    },
    onError: (err) => toast.error(err.message),
  });

  const execute = trpc.eli.executeMission.useMutation({
    onSuccess: (m) => {
      setActiveMission(m as MissionRow);
      utils.eli.listMissions.invalidate();
      utils.eli.overview.invalidate();
      utils.eli.listAudit.invalidate();
      toast.success("Mission executed", { description: "Report saved to the mission record" });
      if (voiceEnabled) speak("Mission executed. The full report is on your screen.");
    },
    onError: (err) => toast.error(err.message),
  });

  const submit = useCallback(
    (text: string, source: "voice" | "typed") => {
      const clean = text.trim();
      if (!clean || preview.isPending) return;
      preview.mutate({ command: clean, source });
      setCommand("");
    },
    [preview]
  );

  const voice = useVoice({
    onFinal: (text) => {
      setTranscriptHistory((h) => [{ text, at: new Date() }, ...h].slice(0, 5));
      submit(text, "voice");
    },
    onError: (err) => {
      if (err === "not-allowed") {
        setLastError("Microphone access denied — allow mic permission in your browser, then try again.");
        toast.error("Microphone blocked", { description: "Allow mic access in the address bar, then press Space." });
      } else if (err === "network") {
        setLastError("Speech service network hiccup — still listening.");
      } else if (err === "no-speech") {
        setLastError("Didn't catch that — speak a little louder or closer to the mic.");
      } else {
        setLastError("This browser doesn't support the Web Speech API. Use Chrome or Edge for voice.");
      }
    },
  });

  // Space toggles voice, Escape stops — the v1 keyboard contract
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      const typing = target.tagName === "INPUT" || target.tagName === "TEXTAREA";
      if (e.code === "Space" && !typing) {
        e.preventDefault();
        if (!voice.supported) {
          toast.error("Voice not supported", { description: "Open in Chrome or Edge for the Web Speech API." });
          return;
        }
        setLastError(null);
        voice.toggle();
      }
      if (e.code === "Escape") voice.stop();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [voice]);

  const busy = preview.isPending || approve.isPending || reject.isPending || execute.isPending;

  return (
    <div className="mx-auto flex max-w-4xl flex-col gap-6">
      {/* Hero orb */}
      <GlassPanel className="scanline relative overflow-hidden p-8">
        <div className="flex flex-col items-center gap-6 text-center">
          <div className="relative">
            {voice.listening && (
              <>
                <span className="pulse-ring" />
                <span className="pulse-ring" />
                <span className="pulse-ring" />
              </>
            )}
            <button
              onClick={() => {
                setLastError(null);
                if (!voice.supported) {
                  toast.error("Voice not supported", { description: "Open in Chrome or Edge." });
                  return;
                }
                voice.toggle();
              }}
              className={cn(
                "animate-float relative flex h-28 w-28 items-center justify-center rounded-full transition-all duration-500",
                voice.listening ? "orb-listening scale-105" : "orb hover:scale-105",
                activeMission?.status === "blocked" && !voice.listening && "orb-blocked"
              )}
              title={voice.listening ? "Stop listening (Esc)" : "Start listening (Space)"}
            >
              {voice.listening ? <Mic className="h-10 w-10 text-white drop-shadow" /> : <MicOff className="h-10 w-10 text-white/70" />}
            </button>
          </div>

          {/* Waveform */}
          <div className="flex h-10 items-center gap-1">
            {WAVE_HEIGHTS.map((h, i) => (
              <span
                key={i}
                className="wave-bar"
                style={{
                  height: `${h}px`,
                  animationDelay: `${i * 0.08}s`,
                  animationPlayState: voice.listening ? "running" : "paused",
                  opacity: voice.listening ? 1 : 0.25,
                }}
              />
            ))}
          </div>

          <div>
            <h1 className="text-2xl font-bold tracking-tight text-white sm:text-3xl">
              {voice.listening ? (
                <>I'm <span className="gradient-text">listening</span>…</>
              ) : (
                <>Command <span className="gradient-text">Eli</span></>
              )}
            </h1>
            <p className="mt-2 text-sm text-slate-400">
              {voice.interim ? (
                <span className="font-mono-el text-emerald-300">“{voice.interim}”</span>
              ) : voice.listening ? (
                "Speak your growth mission — I'll plan it instantly"
              ) : (
                "Press Space or click the orb to talk — or type below"
              )}
            </p>
            {lastError && (
              <p className="mx-auto mt-3 max-w-md rounded-xl border border-amber-400/25 bg-amber-400/10 px-4 py-2 text-xs text-amber-200">
                {lastError}
              </p>
            )}
          </div>

          {/* Command input */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              submit(command, "typed");
            }}
            className="flex w-full max-w-xl items-center gap-2"
          >
            <input
              ref={inputRef}
              value={command}
              onChange={(e) => setCommand(e.target.value)}
              placeholder="e.g. Audit my pest control site for local SEO…"
              className="input-el"
            />
            <button type="submit" disabled={!command.trim() || busy} className="btn-primary shrink-0">
              {preview.isPending ? (
                <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/30 border-t-white" />
              ) : (
                <Send className="h-4 w-4" />
              )}
              <span className="hidden sm:inline">Plan</span>
            </button>
          </form>

          {/* Voice output toggle */}
          <div className="flex flex-wrap items-center justify-center gap-2">
            <button
              onClick={() => {
                setVoiceEnabled(!voiceEnabled);
                if (voiceEnabled) stopSpeaking();
              }}
              className={cn("chip border-white/10 transition-colors", voiceEnabled ? "bg-emerald-400/10 text-emerald-300" : "bg-white/[0.04] text-slate-500")}
              title={ttsSupported ? "Toggle Eli's spoken responses" : "TTS not supported in this browser"}
            >
              {voiceEnabled ? <Volume2 className="h-3 w-3" /> : <VolumeX className="h-3 w-3" />}
              Eli's voice {voiceEnabled ? "on" : "off"}
            </button>
            <span className="chip border-white/10 bg-white/[0.04] text-slate-400">
              <CornerDownLeft className="h-3 w-3" /> Space = talk · Esc = stop
            </span>
            {preview.isPending && (
              <span className="chip border-violet-400/30 bg-violet-400/10 text-violet-300">
                <span className="h-2 w-2 animate-pulse rounded-full bg-violet-300" /> Planning…
              </span>
            )}
          </div>
        </div>
      </GlassPanel>

      {/* Suggestions */}
      {!activeMission && (
        <div className="flex flex-wrap justify-center gap-2">
          {SUGGESTIONS.map((s) => (
            <button
              key={s}
              onClick={() => submit(s, "typed")}
              disabled={busy}
              className="chip glass-hover border-white/10 bg-white/[0.03] px-3.5 py-2 text-xs text-slate-300"
            >
              {s}
            </button>
          ))}
        </div>
      )}

      {/* Transcript history */}
      {transcriptHistory.length > 0 && (
        <div className="flex flex-wrap items-center justify-center gap-2 text-[11px] text-slate-500">
          <span className="font-medium uppercase tracking-wider text-slate-600">Heard:</span>
          {transcriptHistory.map((t, i) => (
            <span key={i} className="chip border-white/[0.07] bg-white/[0.02] text-slate-500">
              “{t.text.length > 40 ? t.text.slice(0, 40) + "…" : t.text}”
            </span>
          ))}
        </div>
      )}

      {/* Active mission */}
      {activeMission && (
        <div>
          <div className="mb-3 flex items-center gap-2">
            <ShieldAlert className="h-4 w-4 text-violet-300" />
            <h2 className="text-sm font-semibold text-white">Active Mission</h2>
          </div>
          <MissionCard
            mission={activeMission}
            defaultOpen
            busy={busy}
            onApprove={(id) => approve.mutate({ id })}
            onReject={(id) => reject.mutate({ id })}
            onExecute={(id) => execute.mutate({ id })}
          />
        </div>
      )}
    </div>
  );
}
