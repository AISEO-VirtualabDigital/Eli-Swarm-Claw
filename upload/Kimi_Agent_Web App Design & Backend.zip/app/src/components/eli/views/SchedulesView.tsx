import { cn } from "@/lib/utils";
import { trpc } from "@/providers/trpc";
import { CalendarClock, Pause, Play, Plus, Trash2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { EmptyState, GlassPanel, PanelHeader } from "../ui";

const PRESETS = [
  { label: "Daily 9am", cron: "0 9 * * *" },
  { label: "Weekly Mon 9am", cron: "0 9 * * 1" },
  { label: "Monthly 1st 9am", cron: "0 9 1 * *" },
];

export function SchedulesView() {
  const [name, setName] = useState("");
  const [command, setCommand] = useState("");
  const [cron, setCron] = useState("0 9 * * 1");
  const [formOpen, setFormOpen] = useState(false);
  const utils = trpc.useUtils();

  const { data: schedules } = trpc.eli.listSchedules.useQuery();
  const invalidate = () => { utils.eli.listSchedules.invalidate(); utils.eli.overview.invalidate(); utils.eli.listAudit.invalidate(); };

  const create = trpc.eli.createSchedule.useMutation({
    onSuccess: () => { invalidate(); setName(""); setCommand(""); setFormOpen(false); toast.success("Schedule created"); },
    onError: (e) => toast.error("Invalid schedule", { description: e.message }),
  });
  const toggle = trpc.eli.toggleSchedule.useMutation({ onSuccess: invalidate, onError: (e) => toast.error(e.message) });
  const remove = trpc.eli.removeSchedule.useMutation({ onSuccess: () => { invalidate(); toast("Schedule deleted"); }, onError: (e) => toast.error(e.message) });

  return (
    <div className="flex flex-col gap-4">
      <GlassPanel>
        <PanelHeader
          icon={<CalendarClock className="h-4 w-4" />}
          title="Scheduled missions"
          subtitle="Recurring organic-growth missions on a cron schedule"
          right={
            <button onClick={() => setFormOpen(!formOpen)} className="btn-primary !px-3.5 !py-2 !text-xs">
              <Plus className="h-3.5 w-3.5" /> New schedule
            </button>
          }
        />
        {formOpen && (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              create.mutate({ name: name.trim(), command: command.trim(), cron: cron.trim() });
            }}
            className="animate-fade-up space-y-3 border-t border-white/[0.06] p-4"
          >
            <div className="grid gap-3 sm:grid-cols-2">
              <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Name — e.g. Weekly SEO audit" className="input-el" required />
              <div>
                <input value={cron} onChange={(e) => setCron(e.target.value)} placeholder="0 9 * * 1" className="input-el font-mono-el" required />
                <div className="mt-1.5 flex flex-wrap gap-1.5">
                  {PRESETS.map((p) => (
                    <button key={p.cron} type="button" onClick={() => setCron(p.cron)} className="chip border-white/10 bg-white/[0.03] text-[9px] text-slate-400 hover:text-white">
                      {p.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            <input value={command} onChange={(e) => setCommand(e.target.value)} placeholder="Mission command — e.g. Audit my site for technical SEO issues" className="input-el" required />
            <div className="flex gap-2">
              <button type="submit" disabled={create.isPending} className="btn-primary !px-4 !py-2 !text-xs">Create</button>
              <button type="button" onClick={() => setFormOpen(false)} className="btn-ghost !px-4 !py-2 !text-xs">Cancel</button>
            </div>
          </form>
        )}
      </GlassPanel>

      {(schedules ?? []).length === 0 ? (
        <EmptyState
          icon={<CalendarClock className="h-5 w-5" />}
          title="No schedules yet"
          hint="Automate recurring missions — a weekly SEO audit every Monday at 9am, a monthly content plan, and more."
        />
      ) : (
        <div className="grid gap-3 sm:grid-cols-2">
          {(schedules ?? []).map((s) => (
            <GlassPanel key={s.id} hover className={cn("p-4", !s.enabled && "opacity-55")}>
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h4 className="text-sm font-semibold text-white">{s.name}</h4>
                  <div className="font-mono-el mt-1 text-[11px] text-violet-300">{s.cron}</div>
                </div>
                <span className={cn("chip", s.enabled ? "border-emerald-400/25 bg-emerald-400/10 text-emerald-300" : "border-white/10 bg-white/[0.03] text-slate-500")}>
                  {s.enabled ? "active" : "paused"}
                </span>
              </div>
              <p className="mt-2 line-clamp-2 text-xs text-slate-400">“{s.command}”</p>
              <div className="mt-3 flex items-center gap-2">
                <button onClick={() => toggle.mutate({ id: s.id })} className="btn-ghost !px-3 !py-1.5 !text-[11px]">
                  {s.enabled ? <Pause className="h-3 w-3" /> : <Play className="h-3 w-3" />}
                  {s.enabled ? "Pause" : "Resume"}
                </button>
                <button onClick={() => remove.mutate({ id: s.id })} className="btn-ghost !px-3 !py-1.5 !text-[11px] hover:!border-red-400/30 hover:!text-red-300">
                  <Trash2 className="h-3 w-3" /> Delete
                </button>
              </div>
            </GlassPanel>
          ))}
        </div>
      )}
    </div>
  );
}
