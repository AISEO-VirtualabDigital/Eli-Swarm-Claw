import { cn } from "@/lib/utils";
import { trpc } from "@/providers/trpc";
import { AlertTriangle, CircleAlert, Globe, History, Info, Loader2, Search } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { EmptyState, GlassPanel, PanelHeader, ScoreRing } from "../ui";

const SEV_ICON = {
  high: <CircleAlert className="h-3.5 w-3.5 text-red-400" />,
  medium: <AlertTriangle className="h-3.5 w-3.5 text-amber-400" />,
  low: <Info className="h-3.5 w-3.5 text-sky-400" />,
};

export function AnalyzerView() {
  const [url, setUrl] = useState("");
  const utils = trpc.useUtils();
  const history = trpc.eli.analysisHistory.useQuery();

  const analyze = trpc.eli.analyzeUrl.useMutation({
    onSuccess: () => { utils.eli.analysisHistory.invalidate(); utils.eli.overview.invalidate(); utils.eli.listAudit.invalidate(); },
    onError: (e) => toast.error("Analysis failed", { description: e.message }),
  });
  const crawl = trpc.eli.crawlSite.useMutation({
    onSuccess: () => { utils.eli.analysisHistory.invalidate(); utils.eli.overview.invalidate(); utils.eli.listAudit.invalidate(); toast.success("Crawl complete"); },
    onError: (e) => toast.error("Crawl failed", { description: e.message }),
  });

  const busy = analyze.isPending || crawl.isPending;
  const report = analyze.data;
  const crawlReport = crawl.data;

  return (
    <div className="flex flex-col gap-5">
      <GlassPanel className="p-5">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (url.trim()) analyze.mutate({ url: url.trim() });
          }}
          className="flex flex-col gap-3 sm:flex-row"
        >
          <input
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="https://yoursite.com"
            className="input-el flex-1"
          />
          <div className="flex gap-2">
            <button type="submit" disabled={!url.trim() || busy} className="btn-primary flex-1 sm:flex-none">
              {analyze.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
              Analyze URL
            </button>
            <button
              type="button"
              disabled={!url.trim() || busy}
              onClick={() => crawl.mutate({ url: url.trim(), maxPages: 10 })}
              className="btn-ghost flex-1 sm:flex-none"
            >
              {crawl.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Globe className="h-4 w-4" />}
              Crawl site
            </button>
          </div>
        </form>
        {crawl.isPending && (
          <p className="mt-3 text-xs text-slate-500">Crawling up to 10 pages — this takes a few seconds…</p>
        )}
      </GlassPanel>

      {/* Single URL report */}
      {report && (
        <div className="animate-fade-up grid gap-4 lg:grid-cols-3">
          <GlassPanel className="flex flex-col items-center justify-center gap-3 p-6">
            <ScoreRing score={report.score} size={120} />
            <div className="text-center">
              <div className="max-w-[220px] truncate text-sm font-medium text-white">{report.finalUrl}</div>
              <div className="mt-1 text-xs text-slate-500">{report.issues.length} issues found</div>
            </div>
          </GlassPanel>

          <GlassPanel className="p-5 lg:col-span-2">
            <h4 className="text-sm font-semibold text-white">Meta & structure</h4>
            <div className="mt-3 space-y-2.5 text-xs">
              <MetaRow label="Title" value={report.meta.title || "—"} ok={report.meta.titleLength >= 30 && report.meta.titleLength <= 60} hint={`${report.meta.titleLength} chars`} />
              <MetaRow label="Description" value={report.meta.description || "—"} ok={report.meta.descriptionLength >= 70 && report.meta.descriptionLength <= 160} hint={`${report.meta.descriptionLength} chars`} />
              <MetaRow label="Canonical" value={report.meta.canonical || "—"} ok={!!report.meta.canonical} />
              <MetaRow label="H1" value={report.headings.h1[0] || "—"} ok={report.headings.h1.length === 1} hint={`${report.headings.h1.length} found`} />
              <div className="grid grid-cols-2 gap-2 pt-2 sm:grid-cols-4">
                <MiniStat label="Words" value={report.content.wordCount} />
                <MiniStat label="Flesch" value={report.content.fleschScore} />
                <MiniStat label="Links" value={`${report.links.internal}in/${report.links.external}ex`} />
                <MiniStat label="Imgs no-alt" value={`${report.images.missingAlt}/${report.images.total}`} />
              </div>
            </div>
          </GlassPanel>

          <GlassPanel className="p-5">
            <h4 className="text-sm font-semibold text-white">Issues</h4>
            <div className="mt-3 space-y-2">
              {report.issues.length === 0 && <p className="text-xs text-emerald-300">No issues — this page is clean.</p>}
              {report.issues.map((issue, i) => (
                <div key={i} className="flex items-start gap-2 text-xs text-slate-300">
                  {SEV_ICON[issue.severity]}
                  <span>{issue.message}</span>
                </div>
              ))}
            </div>
          </GlassPanel>

          <GlassPanel className="p-5">
            <h4 className="text-sm font-semibold text-white">Top keywords</h4>
            <div className="mt-3 space-y-1.5">
              {report.keywords.slice(0, 8).map((k) => (
                <div key={k.word} className="flex items-center gap-2 text-xs">
                  <span className="font-mono-el w-24 truncate text-slate-300">{k.word}</span>
                  <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/[0.06]">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-violet-400 to-cyan-400"
                      style={{ width: `${Math.min(100, k.density * 25)}%` }}
                    />
                  </div>
                  <span className="w-12 text-right text-slate-500">{k.density}%</span>
                </div>
              ))}
            </div>
          </GlassPanel>

          <GlassPanel className="p-5">
            <h4 className="text-sm font-semibold text-white">Technical</h4>
            <div className="mt-3 space-y-2 text-xs">
              <TechRow label="HTML size" value={`${(report.performance.bytes / 1024).toFixed(0)} KB`} />
              <TechRow label="Scripts" value={`${report.performance.scriptCount} (${report.performance.inlineScripts} inline)`} />
              <TechRow label="Stylesheets" value={String(report.performance.stylesheetCount)} />
              <TechRow label="JSON-LD schema" value={report.schema.jsonLdCount > 0 ? report.schema.types.join(", ") || `${report.schema.jsonLdCount} block(s)` : "none"} />
              <TechRow label="Readability grade" value={String(report.content.gradeLevel)} />
            </div>
          </GlassPanel>
        </div>
      )}

      {/* Crawl report */}
      {crawlReport && (
        <GlassPanel className="animate-fade-up">
          <PanelHeader
            icon={<Globe className="h-4 w-4" />}
            title={`Crawl: ${crawlReport.startUrl}`}
            subtitle={`${crawlReport.pagesCrawled} pages · average score ${crawlReport.averageScore}`}
            right={<ScoreRing score={crawlReport.averageScore} size={56} />}
          />
          <div className="grid gap-4 p-5 lg:grid-cols-2">
            <div>
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">Pages</h4>
              <div className="mt-2 space-y-1.5">
                {crawlReport.pages.map((p, i) => (
                  <div key={i} className="flex items-center gap-3 rounded-lg border border-white/[0.06] bg-white/[0.02] px-3 py-2 text-xs">
                    <span
                      className={cn(
                        "font-mono-el w-8 shrink-0 text-right font-bold",
                        p.score >= 80 ? "text-emerald-300" : p.score >= 55 ? "text-amber-300" : "text-red-300"
                      )}
                    >
                      {p.score}
                    </span>
                    <span className="min-w-0 flex-1 truncate text-slate-300">{p.url}</span>
                    {p.error ? (
                      <span className="shrink-0 text-red-400">error</span>
                    ) : (
                      <span className="shrink-0 text-slate-500">{p.issues} issues</span>
                    )}
                  </div>
                ))}
              </div>
            </div>
            <div>
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">Site-wide issues</h4>
              <div className="mt-2 space-y-1.5">
                {crawlReport.topIssues.map((issue, i) => (
                  <div key={i} className="flex items-start gap-2 rounded-lg border border-white/[0.06] bg-white/[0.02] px-3 py-2 text-xs text-slate-300">
                    {SEV_ICON[issue.severity as keyof typeof SEV_ICON] ?? SEV_ICON.low}
                    <span className="flex-1">{issue.message}</span>
                    <span className="text-slate-500">×{issue.affectedPages}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </GlassPanel>
      )}

      {/* History */}
      <GlassPanel>
        <PanelHeader icon={<History className="h-4 w-4" />} title="Analysis history" subtitle="Every scan is saved to your account" />
        <div className="p-4">
          {(history.data ?? []).length === 0 ? (
            <EmptyState icon={<Globe className="h-5 w-5" />} title="No analyses yet" hint="Enter a URL above to run your first SEO deep-scan." />
          ) : (
            <div className="space-y-1.5">
              {(history.data ?? []).map((a) => (
                <div key={a.id} className="flex items-center gap-3 rounded-lg border border-white/[0.06] bg-white/[0.02] px-3 py-2 text-xs">
                  <span className={cn("font-mono-el w-8 text-right font-bold", a.score >= 80 ? "text-emerald-300" : a.score >= 55 ? "text-amber-300" : "text-red-300")}>
                    {a.score}
                  </span>
                  <span className="chip border-white/10 bg-white/[0.03] text-slate-500">{a.kind}</span>
                  <span className="min-w-0 flex-1 truncate text-slate-300">{a.url}</span>
                  <span className="shrink-0 text-slate-600">{new Date(a.createdAt).toLocaleDateString()}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </GlassPanel>
    </div>
  );
}

function MetaRow({ label, value, ok, hint }: { label: string; value: string; ok: boolean; hint?: string }) {
  return (
    <div className="flex items-start gap-2">
      <span className={cn("mt-0.5 h-2 w-2 shrink-0 rounded-full", ok ? "bg-emerald-400" : "bg-amber-400")} />
      <div className="min-w-0">
        <span className="font-medium text-slate-400">{label}: </span>
        <span className="text-slate-200">{value}</span>
        {hint && <span className="ml-1.5 text-slate-600">({hint})</span>}
      </div>
    </div>
  );
}

function MiniStat({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="rounded-lg border border-white/[0.07] bg-white/[0.03] px-3 py-2 text-center">
      <div className="text-sm font-bold text-white">{value}</div>
      <div className="text-[10px] uppercase tracking-wider text-slate-500">{label}</div>
    </div>
  );
}

function TechRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <span className="text-slate-500">{label}</span>
      <span className="font-mono-el truncate text-slate-300">{value}</span>
    </div>
  );
}
