import { cn } from "@/lib/utils";
import { trpc } from "@/providers/trpc";
import { CircleSlash, Eye, ShieldCheck, ShieldAlert, Sprout } from "lucide-react";
import { useState } from "react";
import { GlassPanel, PanelHeader, RiskBadge, StatCard } from "../ui";

export function SafetyView() {
  const [testInput, setTestInput] = useState("");
  const report = trpc.eli.safetyReport.useQuery();
  const check = trpc.eli.safetyCheck.useMutation();

  return (
    <div className="flex flex-col gap-5">
      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard label="Checks run" value={report.data?.totalChecks ?? "—"} icon={<Eye className="h-4 w-4" />} accent="cyan" hint="every command pre-screened" />
        <StatCard label="Blocked" value={report.data?.blocked ?? "—"} icon={<CircleSlash className="h-4 w-4" />} accent="red" hint="quarantined & logged" />
        <StatCard label="Approval-gated" value={report.data?.approvalGated ?? "—"} icon={<ShieldAlert className="h-4 w-4" />} accent="amber" hint="held for your Approve click" />
      </div>

      <GlassPanel className="border-emerald-400/15">
        <div className="flex items-start gap-4 p-5">
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl border border-emerald-400/25 bg-emerald-400/10">
            <Sprout className="h-5 w-5 text-emerald-300" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-emerald-200">Organic Growth Only — enforced at engine level</h3>
            <p className="mt-1 max-w-2xl text-xs leading-relaxed text-slate-400">
              Every command passes the Safety Engine before planning. Paid ads, PPC, sponsored posts and fake reviews are
              permanently blocked — not just gated. Destructive ops, secrets exposure and spam patterns are quarantined.
              What remains is earned growth: SEO, content, authority and genuine distribution.
            </p>
          </div>
        </div>
      </GlassPanel>

      <GlassPanel>
        <PanelHeader icon={<ShieldCheck className="h-4 w-4" />} title="Active guardrail layers" subtitle="9 layers, always on" />
        <div className="grid gap-3 p-4 sm:grid-cols-2 lg:grid-cols-3">
          {(report.data?.features ?? []).map((f) => (
            <div key={f.key} className="rounded-xl border border-white/[0.07] bg-white/[0.02] p-3.5">
              <div className="flex items-center gap-2 text-[13px] font-semibold text-white">
                <ShieldCheck className="h-3.5 w-3.5 text-emerald-300" />
                {f.label}
              </div>
              <p className="mt-1.5 text-[11px] leading-relaxed text-slate-500">{f.description}</p>
            </div>
          ))}
        </div>
      </GlassPanel>

      {/* Live tester */}
      <GlassPanel>
        <PanelHeader icon={<ShieldAlert className="h-4 w-4" />} title="Test the Safety Engine" subtitle="Try any command — see the verdict instantly" />
        <div className="p-5">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (testInput.trim()) check.mutate({ text: testInput.trim() });
            }}
            className="flex flex-col gap-2 sm:flex-row"
          >
            <input
              value={testInput}
              onChange={(e) => setTestInput(e.target.value)}
              placeholder='Try: "launch google ads campaign" — or "audit my site for seo"'
              className="input-el flex-1"
            />
            <button type="submit" disabled={!testInput.trim() || check.isPending} className="btn-primary">
              Check
            </button>
          </form>

          {check.data && (
            <div
              className={cn(
                "animate-fade-up mt-4 rounded-xl border p-4",
                check.data.allowed ? "border-emerald-400/25 bg-emerald-400/[0.07]" : "border-red-400/25 bg-red-400/[0.08]"
              )}
            >
              <div className="flex flex-wrap items-center gap-3">
                <span className={cn("text-sm font-bold", check.data.allowed ? "text-emerald-300" : "text-red-300")}>
                  {check.data.allowed ? "ALLOWED" : "BLOCKED"}
                </span>
                <RiskBadge level={check.data.riskLevel} />
                <span className="chip border-white/10 bg-white/[0.04] text-slate-400">{check.data.category}</span>
                {check.data.requiresApproval && (
                  <span className="chip border-orange-400/30 bg-orange-400/10 text-orange-300">approval required</span>
                )}
                {check.data.quarantine && (
                  <span className="chip border-red-400/30 bg-red-400/10 text-red-300">quarantined</span>
                )}
              </div>
              {check.data.reasons.length > 0 && (
                <ul className="mt-2.5 space-y-1 text-xs text-slate-300">
                  {check.data.reasons.map((r, i) => (
                    <li key={i}>• {r}</li>
                  ))}
                </ul>
              )}
            </div>
          )}
        </div>
      </GlassPanel>

      {/* Recent blocks */}
      {(report.data?.recentBlocks ?? []).length > 0 && (
        <GlassPanel>
          <PanelHeader icon={<CircleSlash className="h-4 w-4" />} title="Recent quarantines" subtitle="Commands the engine blocked" />
          <div className="space-y-1.5 p-4">
            {(report.data?.recentBlocks ?? []).map((log) => (
              <div key={log.id} className="rounded-lg border border-red-400/15 bg-red-400/[0.05] px-3 py-2">
                <div className="flex items-center justify-between gap-2 text-xs">
                  <span className="font-medium text-red-300">{log.event}</span>
                  <span className="shrink-0 text-slate-600">{new Date(log.createdAt).toLocaleString()}</span>
                </div>
                {log.detail && <p className="mt-1 line-clamp-2 text-[11px] text-slate-500">{log.detail}</p>}
              </div>
            ))}
          </div>
        </GlassPanel>
      )}
    </div>
  );
}
