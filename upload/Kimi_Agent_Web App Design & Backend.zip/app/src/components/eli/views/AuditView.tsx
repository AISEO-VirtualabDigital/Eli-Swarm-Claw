import { cn } from "@/lib/utils";
import { trpc } from "@/providers/trpc";
import { ScrollText } from "lucide-react";
import { useState } from "react";
import { EmptyState, GlassPanel, PanelHeader } from "../ui";

const CATEGORIES = ["all", "safety", "mission", "analyzer", "scraper", "vault", "schedule", "system"] as const;

const CAT_COLORS: Record<string, string> = {
  safety: "border-red-400/25 bg-red-400/10 text-red-300",
  mission: "border-violet-400/25 bg-violet-400/10 text-violet-300",
  analyzer: "border-cyan-400/25 bg-cyan-400/10 text-cyan-300",
  scraper: "border-sky-400/25 bg-sky-400/10 text-sky-300",
  vault: "border-emerald-400/25 bg-emerald-400/10 text-emerald-300",
  schedule: "border-amber-400/25 bg-amber-400/10 text-amber-300",
  system: "border-white/10 bg-white/[0.04] text-slate-400",
};

export function AuditView() {
  const [cat, setCat] = useState<(typeof CATEGORIES)[number]>("all");
  const { data: logs, isLoading } = trpc.eli.listAudit.useQuery({ limit: 200 }, { refetchInterval: 20_000 });
  const filtered = (logs ?? []).filter((l) => cat === "all" || l.category === cat);

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap gap-2">
        {CATEGORIES.map((c) => (
          <button
            key={c}
            onClick={() => setCat(c)}
            className={cn(
              "chip px-3 py-1.5 capitalize transition-colors",
              cat === c ? "border-violet-400/40 bg-violet-500/15 text-violet-200" : "border-white/10 bg-white/[0.03] text-slate-400 hover:text-slate-200"
            )}
          >
            {c}
          </button>
        ))}
      </div>

      <GlassPanel>
        <PanelHeader
          icon={<ScrollText className="h-4 w-4" />}
          title="Immutable audit trail"
          subtitle="Every safety check, mission event and scan — append-only, exportable"
        />
        <div className="p-4">
          {isLoading ? (
            <div className="space-y-2">
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="h-12 animate-pulse rounded-lg bg-white/[0.03]" />
              ))}
            </div>
          ) : filtered.length === 0 ? (
            <EmptyState icon={<ScrollText className="h-5 w-5" />} title="No events yet" hint="Actions across Eli OS are recorded here automatically as you work." />
          ) : (
            <div className="space-y-1.5">
              {filtered.map((log) => (
                <div key={log.id} className="flex items-start gap-3 rounded-lg border border-white/[0.05] bg-white/[0.02] px-3 py-2.5">
                  <span className={cn("chip shrink-0", CAT_COLORS[log.category] ?? CAT_COLORS.system)}>{log.category}</span>
                  <div className="min-w-0 flex-1">
                    <div className="text-xs font-medium text-slate-200">{log.event}</div>
                    {log.detail && <div className="font-mono-el mt-0.5 line-clamp-2 whitespace-pre-wrap text-[10px] text-slate-500">{log.detail}</div>}
                  </div>
                  <div className="flex shrink-0 flex-col items-end gap-1">
                    <span className="text-[10px] text-slate-600">{new Date(log.createdAt).toLocaleString()}</span>
                    {(log.riskLevel === "high" || log.riskLevel === "critical") && (
                      <span className={cn("chip !text-[9px]", log.riskLevel === "critical" ? "border-red-400/30 bg-red-400/10 text-red-300" : "border-orange-400/30 bg-orange-400/10 text-orange-300")}>
                        {log.riskLevel}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </GlassPanel>
    </div>
  );
}
