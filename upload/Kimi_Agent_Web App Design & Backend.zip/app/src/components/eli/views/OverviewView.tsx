import { trpc } from "@/providers/trpc";
import { Activity, BookOpen, CalendarClock, CircleSlash, Globe, Sparkles, Target, TrendingUp } from "lucide-react";
import { MissionCard, type MissionRow } from "../MissionPlanCard";
import { EmptyState, GlassPanel, PanelHeader, StatCard } from "../ui";
import type { EliView } from "@/pages/Home";

export function OverviewView({ onNavigate }: { onNavigate: (v: EliView) => void }) {
  const { data, isLoading } = trpc.eli.overview.useQuery(undefined, { refetchInterval: 15_000 });

  if (isLoading || !data) {
    return (
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="glass h-28 animate-pulse" />
        ))}
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Missions" value={data.missions.total} icon={<Target className="h-4 w-4" />} accent="violet" hint={`${data.missions.executed} executed · ${data.missions.preview} awaiting review`} />
        <StatCard label="Avg SEO score" value={data.avgScore ?? "—"} icon={<TrendingUp className="h-4 w-4" />} accent="cyan" hint={`${data.analyses} analyses run`} />
        <StatCard label="Safety blocks" value={data.safetyBlocks} icon={<CircleSlash className="h-4 w-4" />} accent="red" hint="quarantined by guardrails" />
        <StatCard label="Knowledge" value={data.knowledge} icon={<BookOpen className="h-4 w-4" />} accent="emerald" hint={`${data.schedules.active} active schedules`} />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <GlassPanel className="lg:col-span-2">
          <PanelHeader
            icon={<Sparkles className="h-4 w-4" />}
            title="Recent missions"
            subtitle="Latest commands and their lifecycle"
            right={
              <button onClick={() => onNavigate("missions")} className="btn-ghost !px-3 !py-1.5 !text-xs">
                View all
              </button>
            }
          />
          <div className="flex flex-col gap-3 p-4">
            {data.recentMissions.length === 0 ? (
              <EmptyState
                icon={<Target className="h-5 w-5" />}
                title="No missions yet"
                hint="Head to the Voice Console and give Eli a command — press Space to talk."
              />
            ) : (
              data.recentMissions.map((m) => <MissionCard key={m.id} mission={m as MissionRow} />)
            )}
          </div>
        </GlassPanel>

        <div className="flex flex-col gap-4">
          <GlassPanel className="p-5">
            <div className="flex items-center gap-2 text-sm font-semibold text-white">
              <Activity className="h-4 w-4 text-emerald-300" /> System status
            </div>
            <div className="mt-4 space-y-3 text-xs">
              {[
                { label: "Mission planner", ok: true },
                { label: "Safety engine (organic-only)", ok: true },
                { label: "Website analyzer", ok: true },
                { label: "SERP scraper", ok: true },
                { label: "Audit trail", ok: true },
              ].map((s) => (
                <div key={s.label} className="flex items-center justify-between">
                  <span className="text-slate-400">{s.label}</span>
                  <span className="inline-flex items-center gap-1.5 font-medium text-emerald-300">
                    <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" /> online
                  </span>
                </div>
              ))}
            </div>
          </GlassPanel>

          <GlassPanel className="p-5">
            <div className="flex items-center gap-2 text-sm font-semibold text-white">
              <CalendarClock className="h-4 w-4 text-violet-300" /> Schedules
            </div>
            <div className="mt-3 text-3xl font-bold text-white">
              {data.schedules.active}
              <span className="ml-2 text-sm font-normal text-slate-500">/ {data.schedules.total} active</span>
            </div>
            <button onClick={() => onNavigate("schedules")} className="btn-ghost mt-4 w-full !text-xs">
              Manage schedules
            </button>
          </GlassPanel>

          <GlassPanel className="p-5">
            <div className="flex items-center gap-2 text-sm font-semibold text-white">
              <Globe className="h-4 w-4 text-cyan-300" /> Quick actions
            </div>
            <div className="mt-3 grid grid-cols-1 gap-2">
              <button onClick={() => onNavigate("analyzer")} className="btn-ghost !justify-start !text-xs">
                <Globe className="h-3.5 w-3.5" /> Analyze a URL
              </button>
              <button onClick={() => onNavigate("serp")} className="btn-ghost !justify-start !text-xs">
                <TrendingUp className="h-3.5 w-3.5" /> Scrape a SERP
              </button>
              <button onClick={() => onNavigate("console")} className="btn-ghost !justify-start !text-xs">
                <Sparkles className="h-3.5 w-3.5" /> New voice mission
              </button>
            </div>
          </GlassPanel>
        </div>
      </div>
    </div>
  );
}
