import { trpc } from "@/providers/trpc";
import { ExternalLink, FileText, Loader2, Radar, Search } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { GlassPanel, PanelHeader } from "../ui";

export function SerpView() {
  const [query, setQuery] = useState("");
  const [extractUrl, setExtractUrl] = useState("");

  const serp = trpc.eli.serpSearch.useMutation({
    onError: (e) => toast.error("SERP scrape failed", { description: e.message }),
  });
  const extract = trpc.eli.extractPage.useMutation({
    onError: (e) => toast.error("Extraction failed", { description: e.message }),
  });

  return (
    <div className="grid gap-5 lg:grid-cols-2">
      {/* SERP search */}
      <GlassPanel>
        <PanelHeader
          icon={<Radar className="h-4 w-4" />}
          title="SERP intelligence"
          subtitle="Live organic results — no API key, no cost"
        />
        <div className="p-5">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (query.trim()) serp.mutate({ query: query.trim(), maxResults: 10 });
            }}
            className="flex gap-2"
          >
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="e.g. best seo tools for local business"
              className="input-el flex-1"
            />
            <button type="submit" disabled={!query.trim() || serp.isPending} className="btn-primary shrink-0">
              {serp.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
            </button>
          </form>

          <div className="mt-4 space-y-2">
            {serp.data?.map((r) => (
              <div key={r.position} className="group rounded-xl border border-white/[0.07] bg-white/[0.03] p-3 transition-colors hover:border-white/[0.15]">
                <div className="flex items-start gap-3">
                  <span className="font-mono-el flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-violet-500/15 text-xs font-bold text-violet-300">
                    {r.position}
                  </span>
                  <div className="min-w-0 flex-1">
                    <a href={r.url} target="_blank" rel="noreferrer" className="flex items-center gap-1.5 text-[13px] font-medium text-cyan-300 hover:underline">
                      <span className="truncate">{r.title}</span>
                      <ExternalLink className="h-3 w-3 shrink-0 opacity-0 transition-opacity group-hover:opacity-100" />
                    </a>
                    <div className="mt-0.5 truncate text-[11px] text-emerald-400/70">{r.url}</div>
                    {r.snippet && <p className="mt-1 line-clamp-2 text-xs leading-relaxed text-slate-400">{r.snippet}</p>}
                    <div className="mt-1.5 flex items-center gap-2">
                      <span className="chip border-white/10 bg-white/[0.03] text-[9px] text-slate-500">{r.source}</span>
                      <button
                        onClick={() => {
                          setExtractUrl(r.url);
                          extract.mutate({ url: r.url, maxChars: 6000 });
                        }}
                        className="text-[10px] font-medium text-violet-300 hover:text-violet-200"
                      >
                        Extract content →
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
            {serp.data?.length === 0 && <p className="py-6 text-center text-xs text-slate-500">No results parsed — try a different query.</p>}
          </div>
        </div>
      </GlassPanel>

      {/* Content extractor */}
      <GlassPanel>
        <PanelHeader
          icon={<FileText className="h-4 w-4" />}
          title="Content extractor"
          subtitle="Clean article text from any URL — ready for analysis"
        />
        <div className="p-5">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (extractUrl.trim()) extract.mutate({ url: extractUrl.trim(), maxChars: 6000 });
            }}
            className="flex gap-2"
          >
            <input
              value={extractUrl}
              onChange={(e) => setExtractUrl(e.target.value)}
              placeholder="https://competitor.com/their-article"
              className="input-el flex-1"
            />
            <button type="submit" disabled={!extractUrl.trim() || extract.isPending} className="btn-ghost shrink-0">
              {extract.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : "Extract"}
            </button>
          </form>

          {extract.data && (
            <div className="animate-fade-up mt-4">
              <div className="rounded-xl border border-white/[0.07] bg-white/[0.02] p-4">
                <div className="text-sm font-semibold text-white">{extract.data.title || "Untitled page"}</div>
                {extract.data.description && <p className="mt-1 text-xs text-slate-500">{extract.data.description}</p>}
                <div className="mt-2 flex items-center gap-2 text-[10px] text-slate-600">
                  <span className="chip border-white/10 bg-white/[0.03] text-slate-500">{extract.data.wordCount} words</span>
                  {extract.data.truncated && <span className="chip border-amber-400/20 bg-amber-400/10 text-amber-300">truncated</span>}
                </div>
              </div>
              <pre className="font-mono-el mt-3 max-h-96 overflow-y-auto whitespace-pre-wrap rounded-xl border border-white/[0.07] bg-black/30 p-4 text-[11px] leading-relaxed text-slate-300">
                {extract.data.text}
              </pre>
            </div>
          )}
        </div>
      </GlassPanel>
    </div>
  );
}
