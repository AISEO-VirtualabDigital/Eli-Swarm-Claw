import { trpc } from "@/providers/trpc";
import { BookOpen, Plus, Search, Trash2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { EmptyState, GlassPanel, PanelHeader } from "../ui";

export function VaultView() {
  const [q, setQ] = useState("");
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [tags, setTags] = useState("");
  const [formOpen, setFormOpen] = useState(false);
  const utils = trpc.useUtils();

  const list = trpc.eli.listKnowledge.useQuery(undefined, { enabled: q.trim().length === 0 });
  const search = trpc.eli.searchKnowledge.useQuery({ q }, { enabled: q.trim().length > 0 });
  const entries = q.trim() ? search.data : list.data;

  const add = trpc.eli.addKnowledge.useMutation({
    onSuccess: () => {
      utils.eli.listKnowledge.invalidate();
      utils.eli.searchKnowledge.invalidate();
      utils.eli.overview.invalidate();
      setTitle(""); setContent(""); setTags(""); setFormOpen(false);
      toast.success("Saved to Eli's memory");
    },
    onError: (e) => toast.error(e.message),
  });
  const remove = trpc.eli.removeKnowledge.useMutation({
    onSuccess: () => { utils.eli.listKnowledge.invalidate(); utils.eli.overview.invalidate(); toast("Entry removed"); },
    onError: (e) => toast.error(e.message),
  });

  return (
    <div className="flex flex-col gap-4">
      <GlassPanel>
        <PanelHeader
          icon={<BookOpen className="h-4 w-4" />}
          title="Knowledge Vault"
          subtitle="Eli's long-term memory — client notes, playbooks, insights"
          right={
            <button onClick={() => setFormOpen(!formOpen)} className="btn-primary !px-3.5 !py-2 !text-xs">
              <Plus className="h-3.5 w-3.5" /> Add entry
            </button>
          }
        />
        <div className="p-4">
          {formOpen && (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                add.mutate({ title: title.trim(), content: content.trim(), tags: tags.trim() });
              }}
              className="animate-fade-up mb-4 space-y-3 rounded-xl border border-violet-400/20 bg-violet-500/[0.06] p-4"
            >
              <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Title — e.g. Dental clinic client notes" className="input-el" required />
              <textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="The knowledge itself — facts, strategies, snippets, client context…"
                className="input-el min-h-28 resize-y"
                required
              />
              <input value={tags} onChange={(e) => setTags(e.target.value)} placeholder="Tags (comma separated) — e.g. dental, local-seo, client" className="input-el" />
              <div className="flex gap-2">
                <button type="submit" disabled={add.isPending} className="btn-primary !px-4 !py-2 !text-xs">Save</button>
                <button type="button" onClick={() => setFormOpen(false)} className="btn-ghost !px-4 !py-2 !text-xs">Cancel</button>
              </div>
            </form>
          )}

          <div className="relative">
            <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search the vault…" className="input-el !pl-10" />
          </div>
        </div>
      </GlassPanel>

      {(entries ?? []).length === 0 ? (
        <EmptyState
          icon={<BookOpen className="h-5 w-5" />}
          title={q ? "Nothing matches" : "Vault is empty"}
          hint={q ? "Try a different search term." : "Add your first entry — playbooks, client context, proven tactics. Eli keeps it forever."}
        />
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {(entries ?? []).map((entry) => (
            <GlassPanel key={entry.id} hover className="group flex flex-col p-4">
              <div className="flex items-start justify-between gap-2">
                <h4 className="text-sm font-semibold text-white">{entry.title}</h4>
                <button
                  onClick={() => remove.mutate({ id: entry.id })}
                  className="rounded-lg p-1.5 text-slate-600 opacity-0 transition-all hover:bg-red-400/10 hover:text-red-300 group-hover:opacity-100"
                  title="Delete"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
              <p className="mt-2 line-clamp-4 flex-1 whitespace-pre-wrap text-xs leading-relaxed text-slate-400">{entry.content}</p>
              <div className="mt-3 flex flex-wrap items-center gap-1.5">
                {entry.tags
                  .split(",")
                  .map((t) => t.trim())
                  .filter(Boolean)
                  .map((tag) => (
                    <span key={tag} className="chip border-cyan-400/20 bg-cyan-400/[0.07] text-[9px] text-cyan-300">
                      {tag}
                    </span>
                  ))}
                <span className="ml-auto text-[10px] text-slate-600">{new Date(entry.createdAt).toLocaleDateString()}</span>
              </div>
            </GlassPanel>
          ))}
        </div>
      )}
    </div>
  );
}
