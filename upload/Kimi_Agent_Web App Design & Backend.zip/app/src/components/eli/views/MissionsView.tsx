import { cn } from "@/lib/utils";
import { trpc } from "@/providers/trpc";
import { Target } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { MissionCard, type MissionRow } from "../MissionPlanCard";
import { EmptyState } from "../ui";

const FILTERS = ["all", "preview", "approved", "executed", "blocked"] as const;

export function MissionsView() {
  const [filter, setFilter] = useState<(typeof FILTERS)[number]>("all");
  const utils = trpc.useUtils();
  const { data: missions, isLoading } = trpc.eli.listMissions.useQuery({ limit: 100 });

  const invalidate = () => {
    utils.eli.listMissions.invalidate();
    utils.eli.overview.invalidate();
    utils.eli.listAudit.invalidate();
  };
  const approve = trpc.eli.approveMission.useMutation({
    onSuccess: () => { invalidate(); toast.success("Mission approved"); },
    onError: (e) => toast.error(e.message),
  });
  const reject = trpc.eli.rejectMission.useMutation({
    onSuccess: () => { invalidate(); toast("Mission rejected"); },
    onError: (e) => toast.error(e.message),
  });
  const execute = trpc.eli.executeMission.useMutation({
    onSuccess: () => { invalidate(); toast.success("Mission executed"); },
    onError: (e) => toast.error(e.message),
  });

  const busy = approve.isPending || reject.isPending || execute.isPending;
  const filtered = (missions ?? []).filter((m) => filter === "all" || m.status === filter);

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap gap-2">
        {FILTERS.map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={cn(
              "chip px-3.5 py-1.5 capitalize transition-colors",
              filter === f
                ? "border-violet-400/40 bg-violet-500/15 text-violet-200"
                : "border-white/10 bg-white/[0.03] text-slate-400 hover:text-slate-200"
            )}
          >
            {f}
            {f !== "all" && (
              <span className="text-slate-500">
                {(missions ?? []).filter((m) => m.status === f).length}
              </span>
            )}
          </button>
        ))}
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="glass h-24 animate-pulse" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={<Target className="h-5 w-5" />}
          title={filter === "all" ? "No missions yet" : `No ${filter} missions`}
          hint="Missions are created from the Voice Console — type or speak a command to generate a plan."
        />
      ) : (
        <div className="flex flex-col gap-3">
          {filtered.map((m) => (
            <MissionCard
              key={m.id}
              mission={m as MissionRow}
              busy={busy}
              onApprove={(id) => approve.mutate({ id })}
              onReject={(id) => reject.mutate({ id })}
              onExecute={(id) => execute.mutate({ id })}
            />
          ))}
        </div>
      )}
    </div>
  );
}
