import { cn } from "@/lib/utils";
import {
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  CircleSlash,
  Clock,
  Play,
  ShieldAlert,
  Sparkles,
  XCircle,
} from "lucide-react";
import { useState } from "react";
import { GlassPanel, RiskBadge, StatusBadge, type MissionPlan } from "./ui";

export interface MissionRow {
  id: number;
  command: string;
  source: "voice" | "typed" | "schedule";
  plan: string;
  status: "preview" | "approved" | "executed" | "rejected" | "blocked";
  riskLevel: "low" | "medium" | "high" | "critical";
  result: string | null;
  createdAt: Date;
}

export function parsePlan(json: string): MissionPlan | null {
  try {
    const parsed = JSON.parse(json);
    if (parsed && Array.isArray(parsed.steps)) return parsed as MissionPlan;
    return null;
  } catch {
    return null;
  }
}

export function MissionCard({
  mission,
  onApprove,
  onReject,
  onExecute,
  busy,
  defaultOpen = false,
}: {
  mission: MissionRow;
  onApprove?: (id: number) => void;
  onReject?: (id: number) => void;
  onExecute?: (id: number) => void;
  busy?: boolean;
  defaultOpen?: boolean;
}) {
  const [open, setOpen] = useState(defaultOpen);
  const plan = parsePlan(mission.plan);
  const blockedReasons = !plan
    ? (() => {
        try {
          return (JSON.parse(mission.plan).reasons as string[]) ?? [];
        } catch {
          return [];
        }
      })()
    : [];

  return (
    <GlassPanel
      className={cn(
        "animate-fade-up overflow-hidden",
        mission.status === "blocked" && "border-red-400/20"
      )}
    >
      <button onClick={() => setOpen(!open)} className="flex w-full items-start gap-3 px-5 py-4 text-left">
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1.5">
            <StatusBadge status={mission.status} />
            <RiskBadge level={mission.riskLevel} />
            <span className="chip border-white/10 bg-white/[0.04] text-slate-400">
              {mission.source === "voice" ? "🎙 voice" : mission.source}
            </span>
            <span className="text-[10px] text-slate-600">#{mission.id}</span>
          </div>
          <p className="mt-2 line-clamp-2 text-sm font-medium text-white">{mission.command}</p>
          {plan && (
            <div className="mt-1.5 flex flex-wrap items-center gap-2 text-[11px] text-slate-500">
              <Sparkles className="h-3 w-3 text-violet-400" />
              {plan.skills.join(" + ")}
              <span className="inline-flex items-center gap-1">
                <Clock className="h-3 w-3" /> {plan.estimatedDuration}
              </span>
            </div>
          )}
        </div>
        <div className="shrink-0 pt-1 text-slate-500">
          {open ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
        </div>
      </button>

      {open && (
        <div className="border-t border-white/[0.06] px-5 py-4">
          {mission.status === "blocked" && (
            <div className="mb-4 rounded-xl border border-red-400/25 bg-red-400/[0.08] p-4">
              <div className="flex items-center gap-2 text-sm font-semibold text-red-300">
                <CircleSlash className="h-4 w-4" /> Quarantined by Safety Engine
              </div>
              <ul className="mt-2 space-y-1 text-xs text-red-200/70">
                {blockedReasons.map((r, i) => (
                  <li key={i}>• {r}</li>
                ))}
              </ul>
            </div>
          )}

          {plan && (
            <>
              <p className="text-xs leading-relaxed text-slate-400">{plan.summary}</p>
              <div className="mt-4 space-y-2.5">
                {plan.steps.map((step) => (
                  <div key={step.order} className="flex gap-3">
                    <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg border border-white/10 bg-white/[0.04] text-[10px] font-bold text-violet-300">
                      {step.order}
                    </div>
                    <div className="min-w-0">
                      <div className="text-[13px] font-medium text-slate-200">
                        {step.title}
                        <span className="ml-2 text-[10px] font-normal text-slate-500">{step.skill}</span>
                      </div>
                      <div className="text-xs text-slate-500">{step.detail}</div>
                    </div>
                  </div>
                ))}
              </div>

              {plan.approvalGates.length > 0 && (
                <div className="mt-4 rounded-xl border border-orange-400/25 bg-orange-400/[0.07] p-3">
                  <div className="flex items-center gap-2 text-xs font-semibold text-orange-300">
                    <ShieldAlert className="h-3.5 w-3.5" /> Approval gates
                  </div>
                  <ul className="mt-1.5 space-y-0.5 text-[11px] text-orange-200/70">
                    {plan.approvalGates.map((g, i) => (
                      <li key={i}>• {g.replace("Requires human approval: ", "")}</li>
                    ))}
                  </ul>
                </div>
              )}
            </>
          )}

          {mission.result && (
            <div className="mt-4 rounded-xl border border-cyan-400/20 bg-cyan-400/[0.06] p-4">
              <div className="mb-2 flex items-center gap-2 text-xs font-semibold text-cyan-300">
                <CheckCircle2 className="h-3.5 w-3.5" /> Execution report
              </div>
              <pre className="font-mono-el whitespace-pre-wrap text-[11px] leading-relaxed text-cyan-100/70">
                {mission.result}
              </pre>
            </div>
          )}

          {(onApprove || onReject || onExecute) && (
            <div className="mt-4 flex flex-wrap gap-2">
              {mission.status === "preview" && onApprove && (
                <>
                  <button onClick={() => onApprove(mission.id)} disabled={busy} className="btn-primary !px-3.5 !py-2 !text-xs">
                    <CheckCircle2 className="h-3.5 w-3.5" /> Approve
                  </button>
                  {onReject && (
                    <button onClick={() => onReject(mission.id)} disabled={busy} className="btn-ghost !px-3.5 !py-2 !text-xs hover:!border-red-400/30 hover:!text-red-300">
                      <XCircle className="h-3.5 w-3.5" /> Reject
                    </button>
                  )}
                </>
              )}
              {mission.status === "approved" && onExecute && (
                <button
                  onClick={() => onExecute(mission.id)}
                  disabled={busy}
                  className="btn-primary !px-3.5 !py-2 !text-xs"
                  style={{ background: "linear-gradient(135deg,#0891b2,#0d9488)", boxShadow: "0 8px 24px -8px rgba(8,145,178,0.6)" }}
                >
                  <Play className="h-3.5 w-3.5" /> Execute
                </button>
              )}
            </div>
          )}
        </div>
      )}
    </GlassPanel>
  );
}
