import { cn } from "@/lib/utils";
import type { ReactNode } from "react";

/* Shared types for parsed mission plans */
export interface MissionStep {
  order: number;
  title: string;
  detail: string;
  skill: string;
}
export interface MissionPlan {
  title: string;
  summary: string;
  skills: string[];
  steps: MissionStep[];
  approvalGates: string[];
  estimatedDuration: string;
  organicOnly: true;
}

export function GlassPanel({
  children,
  className,
  hover = false,
}: {
  children: ReactNode;
  className?: string;
  hover?: boolean;
}) {
  return <div className={cn("glass", hover && "glass-hover", className)}>{children}</div>;
}

export function PanelHeader({
  icon,
  title,
  subtitle,
  right,
}: {
  icon?: ReactNode;
  title: string;
  subtitle?: string;
  right?: ReactNode;
}) {
  return (
    <div className="flex items-start justify-between gap-4 border-b border-white/[0.06] px-5 py-4">
      <div className="flex items-center gap-3">
        {icon && (
          <div className="flex h-9 w-9 items-center justify-center rounded-xl border border-white/10 bg-white/[0.05] text-violet-300">
            {icon}
          </div>
        )}
        <div>
          <h3 className="text-sm font-semibold text-white">{title}</h3>
          {subtitle && <p className="mt-0.5 text-xs text-slate-400">{subtitle}</p>}
        </div>
      </div>
      {right}
    </div>
  );
}

const RISK_STYLES: Record<string, string> = {
  low: "border-emerald-400/30 bg-emerald-400/10 text-emerald-300",
  medium: "border-amber-400/30 bg-amber-400/10 text-amber-300",
  high: "border-orange-400/30 bg-orange-400/10 text-orange-300",
  critical: "border-red-400/30 bg-red-400/10 text-red-300",
};

export function RiskBadge({ level }: { level: string }) {
  return (
    <span className={cn("chip uppercase tracking-wide", RISK_STYLES[level] ?? RISK_STYLES.low)}>
      {level}
    </span>
  );
}

const STATUS_STYLES: Record<string, { dot: string; text: string; label: string }> = {
  preview: { dot: "bg-violet-400", text: "text-violet-300", label: "Preview" },
  approved: { dot: "bg-emerald-400", text: "text-emerald-300", label: "Approved" },
  executed: { dot: "bg-cyan-400", text: "text-cyan-300", label: "Executed" },
  rejected: { dot: "bg-slate-400", text: "text-slate-400", label: "Rejected" },
  blocked: { dot: "bg-red-400", text: "text-red-300", label: "Blocked" },
};

export function StatusBadge({ status }: { status: string }) {
  const s = STATUS_STYLES[status] ?? STATUS_STYLES.preview;
  return (
    <span className={cn("inline-flex items-center gap-1.5 text-xs font-medium", s.text)}>
      <span className={cn("h-1.5 w-1.5 rounded-full", s.dot)} />
      {s.label}
    </span>
  );
}

export function StatCard({
  label,
  value,
  icon,
  accent = "violet",
  hint,
}: {
  label: string;
  value: string | number;
  icon: ReactNode;
  accent?: "violet" | "cyan" | "emerald" | "red" | "amber";
  hint?: string;
}) {
  const accents: Record<string, string> = {
    violet: "text-violet-300 border-violet-400/20 bg-violet-400/10",
    cyan: "text-cyan-300 border-cyan-400/20 bg-cyan-400/10",
    emerald: "text-emerald-300 border-emerald-400/20 bg-emerald-400/10",
    red: "text-red-300 border-red-400/20 bg-red-400/10",
    amber: "text-amber-300 border-amber-400/20 bg-amber-400/10",
  };
  return (
    <GlassPanel hover className="p-4">
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium uppercase tracking-wider text-slate-400">{label}</span>
        <div className={cn("flex h-8 w-8 items-center justify-center rounded-lg border", accents[accent])}>
          {icon}
        </div>
      </div>
      <div className="mt-3 text-2xl font-bold text-white">{value}</div>
      {hint && <div className="mt-1 text-xs text-slate-500">{hint}</div>}
    </GlassPanel>
  );
}

export function EmptyState({ icon, title, hint }: { icon: ReactNode; title: string; hint: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-14 text-center">
      <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-white/10 bg-white/[0.04] text-slate-500">
        {icon}
      </div>
      <p className="text-sm font-medium text-slate-300">{title}</p>
      <p className="max-w-xs text-xs text-slate-500">{hint}</p>
    </div>
  );
}

export function ScoreRing({ score, size = 96 }: { score: number; size?: number }) {
  const stroke = 8;
  const r = (size - stroke) / 2;
  const circ = 2 * Math.PI * r;
  const color = score >= 80 ? "#34d399" : score >= 55 ? "#fbbf24" : "#f87171";
  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth={stroke} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={color}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={circ}
          strokeDashoffset={circ * (1 - score / 100)}
          style={{ transition: "stroke-dashoffset 0.8s cubic-bezier(0.22,1,0.36,1)", filter: `drop-shadow(0 0 6px ${color}66)` }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-xl font-bold text-white">{score}</span>
        <span className="text-[9px] uppercase tracking-wider text-slate-500">score</span>
      </div>
    </div>
  );
}
