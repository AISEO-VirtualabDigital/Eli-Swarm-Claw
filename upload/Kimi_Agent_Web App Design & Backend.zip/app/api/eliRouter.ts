import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { analyzeHtml, crawlSite, fetchPage } from "./eli/analyzer";
import { executeMissionResult, planMission } from "./eli/planner";
import { evaluateCommand, rateLimit, SAFETY_FEATURES, scanPrivacy } from "./eli/safety";
import { extractContent, scrapeSerp } from "./eli/scraper";
import { createRouter, authedQuery } from "./middleware";
import {
  addKnowledge,
  addSchedule,
  createMission,
  getMission,
  listAnalyses,
  listAuditLogs,
  listKnowledge,
  listMissions,
  listSchedules,
  logAudit,
  removeKnowledge,
  removeSchedule,
  saveAnalysis,
  searchKnowledge,
  toggleSchedule,
  updateMissionStatus,
} from "./queries/eli";

const CRON_RE = /^(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)$/;

function guardRate(userId: number, bucket: string, max = 30) {
  if (!rateLimit(`${bucket}:${userId}`, max)) {
    throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "Rate limit hit — Eli is cooling down for a minute." });
  }
}

export const eliRouter = createRouter({
  // ------------------------------ safety -----------------------------------
  safetyCheck: authedQuery
    .input(z.object({ text: z.string().min(1).max(2000) }))
    .mutation(async ({ ctx, input }) => {
      const verdict = evaluateCommand(input.text);
      await logAudit({
        userId: ctx.user.id,
        event: `Safety check: ${verdict.allowed ? "allowed" : "BLOCKED"}`,
        category: "safety",
        detail: `${input.text.slice(0, 300)}\n→ ${verdict.category} (${verdict.riskLevel}) ${verdict.reasons.join("; ")}`,
        riskLevel: verdict.riskLevel,
      });
      return verdict;
    }),

  safetyReport: authedQuery.query(async ({ ctx }) => {
    const logs = await listAuditLogs(ctx.user.id, 500);
    const safety = logs.filter((l) => l.category === "safety");
    return {
      features: SAFETY_FEATURES,
      totalChecks: safety.length,
      blocked: safety.filter((l) => l.riskLevel === "critical").length,
      approvalGated: safety.filter((l) => l.riskLevel === "high").length,
      recentBlocks: safety.filter((l) => l.riskLevel === "critical").slice(0, 10),
    };
  }),

  privacyScan: authedQuery
    .input(z.object({ text: z.string().min(1).max(5000) }))
    .mutation(({ input }) => scanPrivacy(input.text)),

  // ----------------------------- missions ----------------------------------
  previewMission: authedQuery
    .input(
      z.object({
        command: z.string().min(2).max(1000),
        source: z.enum(["voice", "typed", "schedule"]).default("typed"),
      })
    )
    .mutation(async ({ ctx, input }) => {
      guardRate(ctx.user.id, "preview");

      const verdict = evaluateCommand(input.command);
      await logAudit({
        userId: ctx.user.id,
        event: `Mission command (${input.source})`,
        category: "safety",
        detail: `${input.command}\n→ ${verdict.category} (${verdict.riskLevel})`,
        riskLevel: verdict.riskLevel,
      });

      if (!verdict.allowed) {
        const mission = await createMission({
          userId: ctx.user.id,
          command: input.command,
          source: input.source,
          plan: JSON.stringify({ blocked: true, reasons: verdict.reasons }),
          status: "blocked",
          riskLevel: verdict.riskLevel,
        });
        return { mission, plan: null, verdict };
      }

      const plan = planMission(input.command, verdict.requiresApproval, verdict.reasons);
      const mission = await createMission({
        userId: ctx.user.id,
        command: input.command,
        source: input.source,
        plan: JSON.stringify(plan),
        status: "preview",
        riskLevel: verdict.riskLevel,
      });
      await logAudit({
        userId: ctx.user.id,
        event: "Mission preview generated",
        category: "mission",
        detail: plan.skills.join(", "),
        riskLevel: verdict.riskLevel,
      });
      return { mission, plan, verdict };
    }),

  listMissions: authedQuery
    .input(z.object({ limit: z.number().min(1).max(200).default(50) }).optional())
    .query(({ ctx, input }) => listMissions(ctx.user.id, input?.limit ?? 50)),

  approveMission: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const mission = await getMission(ctx.user.id, input.id);
      if (!mission) throw new TRPCError({ code: "NOT_FOUND", message: "Mission not found" });
      if (mission.status !== "preview") {
        throw new TRPCError({ code: "BAD_REQUEST", message: `Mission is ${mission.status} — only previews can be approved` });
      }
      const updated = await updateMissionStatus(ctx.user.id, input.id, "approved");
      await logAudit({ userId: ctx.user.id, event: `Mission #${input.id} approved by operator`, category: "mission", detail: mission.command });
      return updated;
    }),

  rejectMission: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const mission = await getMission(ctx.user.id, input.id);
      if (!mission) throw new TRPCError({ code: "NOT_FOUND", message: "Mission not found" });
      const updated = await updateMissionStatus(ctx.user.id, input.id, "rejected");
      await logAudit({ userId: ctx.user.id, event: `Mission #${input.id} rejected by operator`, category: "mission", detail: mission.command });
      return updated;
    }),

  executeMission: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      guardRate(ctx.user.id, "execute", 10);
      const mission = await getMission(ctx.user.id, input.id);
      if (!mission) throw new TRPCError({ code: "NOT_FOUND", message: "Mission not found" });
      if (mission.status === "blocked") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Blocked missions can never execute — quarantined by the safety engine" });
      }
      if (mission.status !== "approved") {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Mission must be approved before execution (approval gate)" });
      }
      const plan = JSON.parse(mission.plan);
      const result = executeMissionResult(mission.command, plan);
      const updated = await updateMissionStatus(ctx.user.id, input.id, "executed", result);
      await logAudit({ userId: ctx.user.id, event: `Mission #${input.id} executed`, category: "mission", detail: plan.skills?.join(", ") ?? "" });
      return updated;
    }),

  // ------------------------------ audit ------------------------------------
  listAudit: authedQuery
    .input(z.object({ limit: z.number().min(1).max(500).default(100) }).optional())
    .query(({ ctx, input }) => listAuditLogs(ctx.user.id, input?.limit ?? 100)),

  // ------------------------------ vault ------------------------------------
  listKnowledge: authedQuery.query(({ ctx }) => listKnowledge(ctx.user.id)),
  searchKnowledge: authedQuery
    .input(z.object({ q: z.string().min(1).max(200) }))
    .query(({ ctx, input }) => searchKnowledge(ctx.user.id, input.q)),
  addKnowledge: authedQuery
    .input(
      z.object({
        title: z.string().min(1).max(255),
        content: z.string().min(1).max(20_000),
        tags: z.string().max(500).default(""),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const entry = await addKnowledge({ userId: ctx.user.id, ...input });
      await logAudit({ userId: ctx.user.id, event: "Knowledge entry added", category: "vault", detail: input.title });
      return entry;
    }),
  removeKnowledge: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      await removeKnowledge(ctx.user.id, input.id);
      return { ok: true };
    }),

  // ---------------------------- schedules ----------------------------------
  listSchedules: authedQuery.query(({ ctx }) => listSchedules(ctx.user.id)),
  createSchedule: authedQuery
    .input(
      z.object({
        name: z.string().min(1).max(255),
        command: z.string().min(2).max(1000),
        cron: z.string().min(9).max(64).regex(CRON_RE, "Use standard 5-field cron, e.g. 0 9 * * 1"),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const schedule = await addSchedule({ userId: ctx.user.id, ...input });
      await logAudit({ userId: ctx.user.id, event: "Schedule created", category: "schedule", detail: `${input.name} (${input.cron})` });
      return schedule;
    }),
  toggleSchedule: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(({ ctx, input }) => toggleSchedule(ctx.user.id, input.id)),
  removeSchedule: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      await removeSchedule(ctx.user.id, input.id);
      return { ok: true };
    }),

  // ----------------------------- analyzer ----------------------------------
  analyzeUrl: authedQuery
    .input(z.object({ url: z.string().min(4).max(1000) }))
    .mutation(async ({ ctx, input }) => {
      guardRate(ctx.user.id, "analyze", 20);
      const target = input.url.startsWith("http") ? input.url : `https://${input.url}`;
      try {
        const { html, finalUrl, bytes } = await fetchPage(target);
        const report = analyzeHtml(target, finalUrl, html, bytes);
        await saveAnalysis({
          userId: ctx.user.id,
          url: finalUrl,
          kind: "url",
          score: report.score,
          report: JSON.stringify(report),
        });
        await logAudit({ userId: ctx.user.id, event: "URL analyzed", category: "analyzer", detail: `${finalUrl} → score ${report.score}` });
        return report;
      } catch (err) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: `Could not analyze that URL: ${err instanceof Error ? err.message : "fetch failed"}`,
        });
      }
    }),

  crawlSite: authedQuery
    .input(z.object({ url: z.string().min(4).max(1000), maxPages: z.number().min(1).max(25).default(10) }))
    .mutation(async ({ ctx, input }) => {
      guardRate(ctx.user.id, "crawl", 5);
      try {
        const report = await crawlSite(input.url, input.maxPages);
        await saveAnalysis({
          userId: ctx.user.id,
          url: report.startUrl,
          kind: "crawl",
          score: report.averageScore,
          report: JSON.stringify(report),
        });
        await logAudit({ userId: ctx.user.id, event: "Site crawled", category: "analyzer", detail: `${report.startUrl} → ${report.pagesCrawled} pages, avg ${report.averageScore}` });
        return report;
      } catch (err) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: `Crawl failed: ${err instanceof Error ? err.message : "unknown error"}`,
        });
      }
    }),

  analysisHistory: authedQuery.query(({ ctx }) => listAnalyses(ctx.user.id)),

  // ------------------------------ scraper ----------------------------------
  serpSearch: authedQuery
    .input(z.object({ query: z.string().min(2).max(300), maxResults: z.number().min(1).max(20).default(10) }))
    .mutation(async ({ ctx, input }) => {
      guardRate(ctx.user.id, "serp", 15);
      const results = await scrapeSerp(input.query, input.maxResults);
      await logAudit({ userId: ctx.user.id, event: "SERP scraped", category: "scraper", detail: `"${input.query}" → ${results.length} results` });
      return results;
    }),

  extractPage: authedQuery
    .input(z.object({ url: z.string().min(4).max(1000), maxChars: z.number().min(500).max(20_000).default(6000) }))
    .mutation(async ({ ctx, input }) => {
      guardRate(ctx.user.id, "extract", 15);
      const content = await extractContent(input.url, input.maxChars);
      await logAudit({ userId: ctx.user.id, event: "Content extracted", category: "scraper", detail: `${content.url} → ${content.wordCount} words` });
      return content;
    }),

  // ------------------------------ stats ------------------------------------
  overview: authedQuery.query(async ({ ctx }) => {
    const [missionList, audits, analysesList, scheduleList, vault] = await Promise.all([
      listMissions(ctx.user.id, 200),
      listAuditLogs(ctx.user.id, 500),
      listAnalyses(ctx.user.id, 100),
      listSchedules(ctx.user.id),
      listKnowledge(ctx.user.id, 300),
    ]);
    return {
      missions: {
        total: missionList.length,
        preview: missionList.filter((m) => m.status === "preview").length,
        approved: missionList.filter((m) => m.status === "approved").length,
        executed: missionList.filter((m) => m.status === "executed").length,
        blocked: missionList.filter((m) => m.status === "blocked").length,
      },
      auditEvents: audits.length,
      safetyBlocks: audits.filter((a) => a.category === "safety" && a.riskLevel === "critical").length,
      analyses: analysesList.length,
      avgScore:
        analysesList.length > 0
          ? Math.round(analysesList.reduce((s, a) => s + a.score, 0) / analysesList.length)
          : null,
      schedules: { total: scheduleList.length, active: scheduleList.filter((s) => s.enabled).length },
      knowledge: vault.length,
      recentMissions: missionList.slice(0, 5),
    };
  }),
});
