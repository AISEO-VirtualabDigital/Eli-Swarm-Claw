/**
 * Eli OS Core — SERP Scraper & Content Extractor
 * Free, keyless SERP scraping (DuckDuckGo → Bing fallback) plus clean-text
 * extraction for feeding competitor content into analysis.
 */
import * as cheerio from "cheerio";
import { fetchPage } from "./analyzer";

export interface SerpResult {
  position: number;
  title: string;
  url: string;
  snippet: string;
  source: string;
}

const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36";

async function fetchRaw(url: string, timeoutMs = 12_000): Promise<string> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      signal: controller.signal,
      redirect: "follow",
      headers: {
        "User-Agent": UA,
        Accept: "text/html,application/xhtml+xml",
        "Accept-Language": "en-US,en;q=0.9",
      },
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.text();
  } finally {
    clearTimeout(timer);
  }
}

function normalizeDuckDuckGoUrl(href: string): string {
  try {
    if (href.startsWith("//duckduckgo.com/l/") || href.startsWith("/l/")) {
      const u = new URL(href.startsWith("/") ? `https://duckduckgo.com${href}` : `https:${href}`);
      const uddg = u.searchParams.get("uddg");
      if (uddg) return decodeURIComponent(uddg);
    }
  } catch {
    /* ignore */
  }
  return href;
}

export async function scrapeSerp(query: string, maxResults = 10): Promise<SerpResult[]> {
  const limit = Math.min(Math.max(1, maxResults), 20);

  // Engine 1: DuckDuckGo HTML endpoint
  try {
    const html = await fetchRaw(`https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}`);
    const $ = cheerio.load(html);
    const results: SerpResult[] = [];
    $(".result").each((_, el) => {
      if (results.length >= limit) return;
      const linkEl = $(el).find(".result__a").first();
      const href = linkEl.attr("href") ?? "";
      const url = normalizeDuckDuckGoUrl(href);
      const title = linkEl.text().trim();
      const snippet = $(el).find(".result__snippet").first().text().trim();
      if (title && url.startsWith("http")) {
        results.push({ position: results.length + 1, title, url, snippet, source: "duckduckgo" });
      }
    });
    if (results.length > 0) return results;
  } catch {
    /* fall through to Bing */
  }

  // Engine 2: Bing fallback
  try {
    const html = await fetchRaw(`https://www.bing.com/search?q=${encodeURIComponent(query)}&count=${limit}`);
    const $ = cheerio.load(html);
    const results: SerpResult[] = [];
    $("li.b_algo").each((_, el) => {
      if (results.length >= limit) return;
      const linkEl = $(el).find("h2 a").first();
      const url = linkEl.attr("href") ?? "";
      const title = linkEl.text().trim();
      const snippet = $(el).find(".b_caption p").first().text().trim();
      if (title && url.startsWith("http")) {
        results.push({ position: results.length + 1, title, url, snippet, source: "bing" });
      }
    });
    if (results.length > 0) return results;
  } catch {
    /* fall through */
  }

  throw new Error(
    "Both SERP engines are unreachable from this network right now. Try again in a moment — the scraper rotates DuckDuckGo and Bing automatically."
  );
}

export interface ExtractedContent {
  url: string;
  title: string;
  description: string;
  text: string;
  wordCount: number;
  truncated: boolean;
}

export async function extractContent(url: string, maxChars = 6000): Promise<ExtractedContent> {
  const target = url.startsWith("http") ? url : `https://${url}`;
  const { html, finalUrl } = await fetchPage(target);
  const $ = cheerio.load(html);

  const title = $("title").first().text().trim();
  const description = $('meta[name="description"]').attr("content")?.trim() ?? "";

  const root = $.root().clone();
  root.find("script,style,noscript,svg,iframe,form,header,footer,nav,aside,[role=navigation],[role=banner],[class*=cookie],[id*=cookie],[class*=popup],[class*=modal],[class*=newsletter]").remove();

  // Prefer main content containers when present
  const main = root.find("main, article, [role=main], .post-content, .entry-content, .article-content").first();
  const textSource = main.length > 0 ? main : root.find("body").first();
  const text = textSource.text().replace(/\s+/g, " ").trim();
  const wordCount = text.split(/\s+/).filter(Boolean).length;
  const truncated = text.length > maxChars;

  return {
    url: finalUrl,
    title,
    description,
    text: truncated ? text.slice(0, maxChars) + "…" : text,
    wordCount,
    truncated,
  };
}
