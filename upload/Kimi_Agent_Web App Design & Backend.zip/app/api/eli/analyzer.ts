/**
 * Eli OS Core — Website Analyzer
 * Server-side fetch + deep on-page SEO analysis, readability and keywords.
 */
import * as cheerio from "cheerio";

export interface SeoIssue {
  severity: "high" | "medium" | "low";
  message: string;
}

export interface AnalysisReport {
  url: string;
  finalUrl: string;
  fetchedAt: string;
  score: number;
  meta: {
    title: string;
    titleLength: number;
    description: string;
    descriptionLength: number;
    canonical: string;
    robots: string;
    ogTitle: string;
    ogDescription: string;
  };
  headings: { h1: string[]; h2Count: number; h3Count: number; total: number };
  links: { total: number; internal: number; external: number; nofollow: number };
  images: { total: number; missingAlt: number };
  schema: { jsonLdCount: number; types: string[] };
  content: { wordCount: number; fleschScore: number; gradeLevel: number };
  keywords: { word: string; count: number; density: number }[];
  performance: { bytes: number; scriptCount: number; stylesheetCount: number; inlineScripts: number };
  issues: SeoIssue[];
}

const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36 EliOS-Analyzer/1.0";

export async function fetchPage(url: string, timeoutMs = 15_000): Promise<{ html: string; finalUrl: string; bytes: number }> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      signal: controller.signal,
      redirect: "follow",
      headers: { "User-Agent": UA, Accept: "text/html,application/xhtml+xml" },
    });
    if (!res.ok) throw new Error(`HTTP ${res.status} ${res.statusText}`);
    const html = await res.text();
    return { html, finalUrl: res.url, bytes: new TextEncoder().encode(html).length };
  } finally {
    clearTimeout(timer);
  }
}

const STOP_WORDS = new Set(
  "the a an and or but if then else for to of in on at by with from as is are was were be been being it its this that these those you your we our they their he she his her not no yes do does did have has had will would can could should may might must i me my mine us them about into over under again further once here there when where why how all any both each few more most other some such only own same so than too very just".split(
    " "
  )
);

function countSyllables(word: string): number {
  const w = word.toLowerCase().replace(/[^a-z]/g, "");
  if (!w) return 0;
  if (w.length <= 3) return 1;
  const groups = w.replace(/(?:[^laeiouy]e|ed|es)$/, "").replace(/^y/, "").match(/[aeiouy]{1,2}/g);
  return Math.max(1, groups ? groups.length : 1);
}

function flesch(text: string): { fleschScore: number; gradeLevel: number; wordCount: number } {
  const sentences = text.split(/[.!?]+/).filter((s) => s.trim().length > 0);
  const words = text.split(/\s+/).filter((w) => /[a-zA-Z]/.test(w));
  const wordCount = words.length;
  if (wordCount < 20 || sentences.length === 0) return { fleschScore: 0, gradeLevel: 0, wordCount };
  const syllables = words.reduce((sum, w) => sum + countSyllables(w), 0);
  const wps = wordCount / sentences.length;
  const spw = syllables / wordCount;
  const fleschScore = Math.round(Math.min(100, Math.max(0, 206.835 - 1.015 * wps - 84.6 * spw)) * 10) / 10;
  const gradeLevel = Math.round(Math.max(0, 0.39 * wps + 11.8 * spw - 15.59) * 10) / 10;
  return { fleschScore, gradeLevel, wordCount };
}

export function analyzeHtml(url: string, finalUrl: string, html: string, bytes: number): AnalysisReport {
  const $ = cheerio.load(html);

  const title = $("title").first().text().trim();
  const description = $('meta[name="description"]').attr("content")?.trim() ?? "";
  const canonical = $('link[rel="canonical"]').attr("href")?.trim() ?? "";
  const robots = $('meta[name="robots"]').attr("content")?.trim() ?? "";
  const ogTitle = $('meta[property="og:title"]').attr("content")?.trim() ?? "";
  const ogDescription = $('meta[property="og:description"]').attr("content")?.trim() ?? "";

  const h1 = $("h1").map((_, el) => $(el).text().trim()).get().filter(Boolean);
  const h2Count = $("h2").length;
  const h3Count = $("h3").length;
  const totalHeadings = $("h1,h2,h3,h4,h5,h6").length;

  let baseHost = "";
  try {
    baseHost = new URL(finalUrl).hostname.replace(/^www\./, "");
  } catch {
    /* ignore */
  }
  let internal = 0,
    external = 0,
    nofollow = 0;
  $("a[href]").each((_, el) => {
    const href = ($(el).attr("href") ?? "").trim();
    const rel = $(el).attr("rel") ?? "";
    if (/\bnofollow\b/.test(rel)) nofollow++;
    if (!href || href.startsWith("#") || href.startsWith("mailto:") || href.startsWith("tel:")) return;
    try {
      const host = new URL(href, finalUrl).hostname.replace(/^www\./, "");
      if (host === baseHost) internal++;
      else external++;
    } catch {
      /* ignore */
    }
  });

  const totalLinks = $("a[href]").length;
  const totalImages = $("img").length;
  const missingAlt = $("img").filter((_, el) => !($(el).attr("alt") ?? "").trim()).length;

  const types: string[] = [];
  $('script[type="application/ld+json"]').each((_, el) => {
    try {
      const data = JSON.parse($(el).contents().text());
      const items = Array.isArray(data) ? data : [data];
      for (const item of items) {
        const t = item?.["@type"];
        if (t) types.push(...(Array.isArray(t) ? t : [t]).map(String));
      }
    } catch {
      /* ignore malformed JSON-LD */
    }
  });

  // Visible text for readability + keywords
  const clone = $.root().clone();
  clone.find("script,style,noscript,svg,header,footer,nav").remove();
  const bodyText = clone.text().replace(/\s+/g, " ").trim();
  const { fleschScore, gradeLevel, wordCount } = flesch(bodyText);

  const freq = new Map<string, number>();
  for (const raw of bodyText.toLowerCase().split(/[^a-z0-9']+/)) {
    const w = raw.replace(/^'+|'+$/g, "");
    if (w.length < 3 || STOP_WORDS.has(w) || /^\d+$/.test(w)) continue;
    freq.set(w, (freq.get(w) ?? 0) + 1);
  }
  const keywords = [...freq.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, 15)
    .map(([word, count]) => ({
      word,
      count,
      density: Math.round((count / Math.max(1, wordCount)) * 1000) / 10,
    }));

  const scriptCount = $("script").length;
  const stylesheetCount = $('link[rel="stylesheet"]').length;
  const inlineScripts = $("script").filter((_, el) => !$(el).attr("src")).length;

  const issues: SeoIssue[] = [];
  if (!title) issues.push({ severity: "high", message: "Missing <title> tag" });
  else if (title.length < 30) issues.push({ severity: "medium", message: `Title too short (${title.length} chars — aim for 30-60)` });
  else if (title.length > 60) issues.push({ severity: "medium", message: `Title too long (${title.length} chars — aim for 30-60)` });
  if (!description) issues.push({ severity: "high", message: "Missing meta description" });
  else if (description.length < 70) issues.push({ severity: "low", message: `Meta description short (${description.length} chars — aim for 70-160)` });
  else if (description.length > 160) issues.push({ severity: "medium", message: `Meta description too long (${description.length} chars — aim for 70-160)` });
  if (h1.length === 0) issues.push({ severity: "high", message: "Missing H1 heading" });
  if (h1.length > 1) issues.push({ severity: "medium", message: `Multiple H1 headings (${h1.length}) — use exactly one` });
  if (!canonical) issues.push({ severity: "low", message: "No canonical URL declared" });
  if (!ogTitle) issues.push({ severity: "low", message: "Missing Open Graph title (social sharing)" });
  if (missingAlt > 0) issues.push({ severity: "low", message: `${missingAlt} of ${totalImages} images missing alt text` });
  if (types.length === 0) issues.push({ severity: "medium", message: "No JSON-LD structured data found" });
  if (wordCount < 300) issues.push({ severity: "medium", message: `Thin content (${wordCount} words — aim for 600+ on key pages)` });
  if (/noindex/i.test(robots)) issues.push({ severity: "high", message: "Page is set to noindex — invisible to search engines" });
  if (bytes > 1_500_000) issues.push({ severity: "medium", message: `Heavy HTML (${(bytes / 1024 / 1024).toFixed(1)} MB) — hurts Core Web Vitals` });

  const penalty = issues.reduce((sum, i) => sum + (i.severity === "high" ? 15 : i.severity === "medium" ? 8 : 3), 0);
  const score = Math.max(0, Math.min(100, 100 - penalty));

  return {
    url,
    finalUrl,
    fetchedAt: new Date().toISOString(),
    score,
    meta: {
      title,
      titleLength: title.length,
      description,
      descriptionLength: description.length,
      canonical,
      robots,
      ogTitle,
      ogDescription,
    },
    headings: { h1: h1.slice(0, 5), h2Count, h3Count, total: totalHeadings },
    links: { total: totalLinks, internal, external, nofollow },
    images: { total: totalImages, missingAlt },
    schema: { jsonLdCount: $('script[type="application/ld+json"]').length, types: [...new Set(types)] },
    content: { wordCount, fleschScore, gradeLevel },
    keywords,
    performance: { bytes, scriptCount, stylesheetCount, inlineScripts },
    issues,
  };
}

export interface CrawlPageResult {
  url: string;
  score: number;
  title: string;
  issues: number;
  error?: string;
}

export interface CrawlReport {
  startUrl: string;
  pagesCrawled: number;
  averageScore: number;
  pages: CrawlPageResult[];
  topIssues: { severity: string; message: string; affectedPages: number }[];
}

export async function crawlSite(startUrl: string, maxPages = 10): Promise<CrawlReport> {
  let origin: URL;
  try {
    origin = new URL(startUrl.startsWith("http") ? startUrl : `https://${startUrl}`);
  } catch {
    throw new Error("Invalid URL");
  }

  const visited = new Set<string>();
  const queue: string[] = [origin.toString()];
  const pages: CrawlPageResult[] = [];
  const issueMap = new Map<string, { severity: string; count: number }>();

  while (queue.length > 0 && pages.length < Math.min(maxPages, 25)) {
    const url = queue.shift()!;
    const normalized = url.split("#")[0];
    if (visited.has(normalized)) continue;
    visited.add(normalized);

    try {
      const { html, finalUrl, bytes } = await fetchPage(normalized, 12_000);
      const report = analyzeHtml(normalized, finalUrl, html, bytes);
      pages.push({ url: normalized, score: report.score, title: report.meta.title, issues: report.issues.length });
      for (const issue of report.issues) {
        const entry = issueMap.get(issue.message) ?? { severity: issue.severity, count: 0 };
        entry.count++;
        issueMap.set(issue.message, entry);
      }

      // Enqueue same-origin links
      const $ = cheerio.load(html);
      $("a[href]").each((_, el) => {
        if (pages.length + queue.length >= Math.min(maxPages, 25)) return;
        try {
          const u = new URL(($(el).attr("href") ?? "").trim(), finalUrl);
          if (u.origin === origin.origin && !visited.has(u.toString().split("#")[0])) {
            queue.push(u.toString().split("#")[0]);
          }
        } catch {
          /* ignore */
        }
      });
    } catch (err) {
      pages.push({
        url: normalized,
        score: 0,
        title: "",
        issues: 1,
        error: err instanceof Error ? err.message : "Fetch failed",
      });
    }
  }

  const scored = pages.filter((p) => !p.error);
  const averageScore =
    scored.length > 0 ? Math.round(scored.reduce((s, p) => s + p.score, 0) / scored.length) : 0;

  const topIssues = [...issueMap.entries()]
    .map(([message, v]) => ({ severity: v.severity, message, affectedPages: v.count }))
    .sort((a, b) => b.affectedPages - a.affectedPages)
    .slice(0, 10);

  return { startUrl: origin.toString(), pagesCrawled: pages.length, averageScore, pages, topIssues };
}
