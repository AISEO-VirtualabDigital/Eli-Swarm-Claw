/**
 * Eli OS Core — Mission Planner
 * Deterministic organic-growth planner: routes a natural-language command
 * to skills and produces a structured, approvable mission plan.
 */

export interface MissionStep {
  order: number;
  title: string;
  detail: string;
  skill: string;
}

export interface MissionPlan {
  title: string;
  summary: string;
  skills: string[];
  steps: MissionStep[];
  approvalGates: string[];
  estimatedDuration: string;
  organicOnly: true;
}

interface SkillRoute {
  skill: string;
  match: RegExp;
  steps: [string, string][];
}

const ROUTES: SkillRoute[] = [
  {
    skill: "SEO Audit",
    match: /\b(seo|audit|rank|ranking|technical|on[- ]?page|crawl|index)\b/i,
    steps: [
      ["Crawl target pages", "Fetch and parse pages, extract meta tags, headings, links, images and schema markup"],
      ["Score on-page SEO", "Evaluate title/description quality, H1 structure, alt coverage, internal linking and readability"],
      ["Prioritize fixes", "Rank issues by severity (high → medium → low) with concrete fix instructions"],
      ["Track baseline", "Save scores to history so improvements are measurable over time"],
    ],
  },
  {
    skill: "Keyword Research",
    match: /\b(keywords?|serp|competitors?|search\s*terms?|queries)\b/i,
    steps: [
      ["Scrape the live SERP", "Pull the top organic results for the target query — no paid API needed"],
      ["Profile top competitors", "Extract titles, snippets and positioning of the top 10 ranking pages"],
      ["Extract content angles", "Pull clean text from competitor pages to identify topics and gaps"],
      ["Build keyword map", "Cluster primary, secondary and long-tail keywords with search intent"],
    ],
  },
  {
    skill: "Content Engine",
    match: /\b(content|blog|article|write|post|copy|outline)\b/i,
    steps: [
      ["Research the topic", "Gather SERP context and competitor coverage for the subject"],
      ["Draft structured outline", "H2/H3 outline mapped to search intent and target keywords"],
      ["Write optimized draft", "Readable, original draft with semantic keywords and internal link slots"],
      ["Readability & SEO pass", "Flesch score check, keyword density balance, meta title/description suggestions"],
    ],
  },
  {
    skill: "Local SEO",
    match: /\b(local|maps|gmb|google\s*business|citation|near me)\b/i,
    steps: [
      ["Audit local presence", "Check NAP consistency, categories and listing completeness"],
      ["Citation opportunities", "List high-authority directories relevant to the niche and region"],
      ["Local content plan", "Location pages and locally-relevant content topics"],
      ["Review strategy", "Ethical review-generation workflow (no fake reviews — ever)"],
    ],
  },
  {
    skill: "Authority Builder",
    match: /\b(backlinks?|authority|outreach|guest\s*post|digital\s*pr)\b/i,
    steps: [
      ["Find link prospects", "Identify relevant, real sites worth earning links from (white-hat only)"],
      ["Craft value angles", "Define the asset or insight that earns the link"],
      ["Outreach templates", "Personalized, non-spammy outreach drafts"],
      ["Track earned links", "Log acquired mentions and monitor over time"],
    ],
  },
  {
    skill: "Video Growth",
    match: /\b(youtube|video|channel)\b/i,
    steps: [
      ["Channel & video audit", "Titles, descriptions, tags, thumbnails and watch-time signals"],
      ["Topic research", "Search-demand-driven video topics in the niche"],
      ["Metadata optimization", "Rewritten titles/descriptions aligned to search intent"],
      ["Publishing cadence", "Sustainable organic upload schedule"],
    ],
  },
  {
    skill: "Site Builder",
    match: /\b(website|landing|page|site|build|design)\b/i,
    steps: [
      ["Structure the page", "Section plan: hero, value props, proof, offer, FAQ, footer"],
      ["Write conversion copy", "Benefit-led headlines and scannable sections"],
      ["Technical foundations", "Semantic HTML, meta tags, schema, fast loading, mobile-first"],
      ["Launch checklist", "Indexing, sitemap, analytics hooks and post-launch monitoring"],
    ],
  },
  {
    skill: "Analytics",
    match: /\b(analytics|traffic|metrics?|report|performance|data)\b/i,
    steps: [
      ["Define KPIs", "Organic sessions, rankings, conversions — no paid metrics"],
      ["Baseline current state", "Snapshot current scores and visibility"],
      ["Insight extraction", "What's working, what's decaying, where the opportunity is"],
      ["Action list", "Prioritized next moves tied to the data"],
    ],
  },
];

const FALLBACK: SkillRoute = {
  skill: "Growth Strategy",
  match: /.*/,
  steps: [
    ["Clarify the objective", "Break the command into measurable organic-growth outcomes"],
    ["Research the landscape", "SERP and competitor reconnaissance for the space"],
    ["Design the plan", "Sequenced organic tactics: SEO, content, authority, distribution"],
    ["Define success metrics", "KPIs and checkpoints to track progress"],
  ],
};

export function planMission(command: string, requiresApproval: boolean, gateReasons: string[]): MissionPlan {
  const matched = ROUTES.filter((r) => r.match.test(command));
  const routes = matched.length > 0 ? matched.slice(0, 2) : [FALLBACK];

  const steps: MissionStep[] = [];
  let order = 1;
  for (const route of routes) {
    for (const [title, detail] of route.steps) {
      steps.push({ order: order++, title, detail, skill: route.skill });
    }
  }

  const skills = routes.map((r) => r.skill);
  const title =
    command.length > 70 ? command.slice(0, 67).trimEnd() + "…" : command;

  return {
    title,
    summary: `${skills.join(" + ")} mission generated from your command. ${
      matched.length > 1 ? `Also routed to ${skills[1]} based on detected intent.` : "Routed to the best-fit skill."
    } All tactics are 100% organic.`,
    skills,
    steps,
    approvalGates: requiresApproval ? gateReasons.filter((r) => r.startsWith("Requires human approval")) : [],
    estimatedDuration: `${steps.length * 15}-${steps.length * 30} min`,
    organicOnly: true,
  };
}

export function executeMissionResult(command: string, plan: MissionPlan): string {
  const lines = [
    `Mission executed in organic mode.`,
    ``,
    `Command: "${command}"`,
    `Skills engaged: ${plan.skills.join(", ")}`,
    ``,
    `Completed ${plan.steps.length} steps:`,
    ...plan.steps.map((s) => `${s.order}. [${s.skill}] ${s.title} — ${s.detail}`),
    ``,
    `Deliverables ready for operator review. No paid channels used. Logged to the immutable audit trail.`,
  ];
  return lines.join("\n");
}
