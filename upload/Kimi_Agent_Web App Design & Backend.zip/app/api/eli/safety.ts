/**
 * Eli OS Core — Safety Engine
 * Organic-growth-only guardrails. Paid advertising is permanently blocked.
 */

export type RiskLevel = "low" | "medium" | "high" | "critical";

export interface SafetyVerdict {
  allowed: boolean;
  riskLevel: RiskLevel;
  category: string;
  reasons: string[];
  requiresApproval: boolean;
  quarantine: boolean;
}

interface PatternGroup {
  category: string;
  riskLevel: RiskLevel;
  patterns: RegExp[];
  reason: string;
}

/** Permanently blocked — paid advertising (organic growth only) */
const AD_PATTERNS: RegExp[] = [
  /\b(launch|run|create|start|set up|buy)\b.{0,30}\b(ads?|advertising|campaign)s?\b/i,
  /\b(google|facebook|meta|instagram|tiktok|linkedin|youtube|twitter|x)\s+ads?\b/i,
  /\b(ppc|cpc|cpm|paid\s*(search|social|traffic|media|promotion))\b/i,
  /\b(display\s*ads?|retargeting|remarketing|programmatic)\b/i,
  /\b(boost(ed)?\s*post|sponsored\s*(content|post|listing))\b/i,
  /\b(ad\s*(spend|budget|campaign))\b/i,
];

const BLOCKED_GROUPS: PatternGroup[] = [
  {
    category: "paid_advertising",
    riskLevel: "critical",
    patterns: AD_PATTERNS,
    reason:
      "Paid advertising is permanently disabled. Eli OS enforces organic growth only (SEO, content, authority, earned media).",
  },
  {
    category: "destructive",
    riskLevel: "critical",
    patterns: [
      /\b(delete|wipe|drop|truncate|destroy)\b.{0,25}\b(database|data|table|all records)\b/i,
      /\b(rm\s*-rf|format\s*disk|factory\s*reset)\b/i,
    ],
    reason: "Destructive data operations are blocked.",
  },
  {
    category: "security_abuse",
    riskLevel: "critical",
    patterns: [
      /\b(sql\s*injection|xss|cross[- ]site\s*scripting)\b/i,
      /\b(bypass|disable|skip)\b.{0,20}\b(approval|safety|guardrail|auth)\b/i,
      /\b(exfiltrate|steal|leak)\b.{0,20}\b(data|credentials|secrets|keys)\b/i,
      /\beval\s*\(|\bexec\s*\(/i,
    ],
    reason: "Security-abuse patterns are blocked.",
  },
  {
    category: "financial",
    riskLevel: "critical",
    patterns: [
      /\b(transfer|wire|send)\b.{0,20}\b(funds|money|payment)\b/i,
      /\b(crypto|bitcoin|btc|eth)\b.{0,20}\b(transfer|send|payment)\b/i,
      /\bapprove\b.{0,15}\bpayment\b/i,
    ],
    reason: "Financial transactions are outside Eli's authority.",
  },
  {
    category: "illegal_or_spam",
    riskLevel: "critical",
    patterns: [
      /\b(spam|phishing|ddos|botnet)\b/i,
      /\b(buy|purchase)\b.{0,15}\b(backlinks?|followers|likes|reviews)\b/i,
      /\b(scrape|harvest)\b.{0,20}\b(personal\s*data|emails?|phone\s*numbers)\b/i,
      /\bfake\s*(reviews?|testimonials?)\b/i,
    ],
    reason: "Illegal, spam, or black-hat activity is blocked.",
  },
];

/** Risky but legitimate — needs a human Approve click */
const APPROVAL_GATES: { pattern: RegExp; label: string }[] = [
  { pattern: /\bpublish\b/i, label: "Publishing content publicly" },
  { pattern: /\b(send|blast)\b.{0,20}\b(emails?|newsletter|dm)\b/i, label: "Sending emails or messages" },
  { pattern: /\binstall\b.{0,20}\b(plugins?|themes?|extensions?)\b/i, label: "Installing plugins or code" },
  { pattern: /\bdeploy\b/i, label: "Deploying code changes" },
  { pattern: /\bdns\b/i, label: "Changing DNS records" },
  { pattern: /\b(delete|remove)\b.{0,20}\b(page|post|content)\b/i, label: "Removing existing content" },
];

/** Content safety patterns scanned in every command */
const CONTENT_SAFETY: { pattern: RegExp; label: string }[] = [
  { pattern: /<script[\s>]/i, label: "Embedded script tag" },
  { pattern: /\b(violence|hate\s*speech|extremis[mt])\b/i, label: "Toxic content reference" },
];

/** Secrets detection (API keys, tokens, connection strings) */
const SECRET_PATTERNS: { pattern: RegExp; label: string }[] = [
  { pattern: /sk-[A-Za-z0-9_-]{16,}/, label: "OpenAI-style API key" },
  { pattern: /sk-ant-[A-Za-z0-9_-]{10,}/, label: "Anthropic API key" },
  { pattern: /AKIA[0-9A-Z]{16}/, label: "AWS access key" },
  { pattern: /ghp_[A-Za-z0-9]{20,}/, label: "GitHub token" },
  { pattern: /-----BEGIN [A-Z ]*PRIVATE KEY-----/, label: "Private key block" },
  { pattern: /(mysql|postgres|mongodb):\/\/[^\s]+/i, label: "Database connection string" },
  { pattern: /eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}/, label: "JWT token" },
];

const PII_PATTERNS: { pattern: RegExp; label: string }[] = [
  { pattern: /\b\d{3}-\d{2}-\d{4}\b/, label: "SSN" },
  { pattern: /\b(?:\d[ -]?){13,16}\b/, label: "Credit card number" },
  { pattern: /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/, label: "Email address" },
];

export function evaluateCommand(raw: string): SafetyVerdict {
  const text = raw.trim();
  const reasons: string[] = [];

  // 1. Secrets — immediate block
  for (const s of SECRET_PATTERNS) {
    if (s.pattern.test(text)) {
      return {
        allowed: false,
        riskLevel: "critical",
        category: "secrets_exposure",
        reasons: [`Detected ${s.label} in the command. Never paste secrets into Eli.`],
        requiresApproval: false,
        quarantine: true,
      };
    }
  }

  // 2. Blocked groups
  for (const group of BLOCKED_GROUPS) {
    if (group.patterns.some((p) => p.test(text))) {
      return {
        allowed: false,
        riskLevel: group.riskLevel,
        category: group.category,
        reasons: [group.reason],
        requiresApproval: false,
        quarantine: true,
      };
    }
  }

  // 3. Content safety
  for (const c of CONTENT_SAFETY) {
    if (c.pattern.test(text)) {
      return {
        allowed: false,
        riskLevel: "high",
        category: "content_safety",
        reasons: [`Content safety flag: ${c.label}.`],
        requiresApproval: false,
        quarantine: true,
      };
    }
  }

  // 4. Approval gates
  const gates = APPROVAL_GATES.filter((g) => g.pattern.test(text)).map((g) => g.label);
  if (gates.length > 0) {
    reasons.push(...gates.map((g) => `Requires human approval: ${g}`));
  }

  // 5. PII note (allowed, but flagged medium)
  const pii = PII_PATTERNS.filter((p) => p.pattern.test(text)).map((p) => p.label);
  if (pii.length > 0) {
    reasons.push(`PII detected (${pii.join(", ")}) — will be redacted in logs.`);
  }

  const riskLevel: RiskLevel = gates.length > 0 ? "high" : pii.length > 0 ? "medium" : "low";
  return {
    allowed: true,
    riskLevel,
    category: gates.length > 0 ? "approval_gate" : pii.length > 0 ? "pii_detected" : "standard",
    reasons,
    requiresApproval: gates.length > 0,
    quarantine: false,
  };
}

export interface PrivacyScan {
  secrets: string[];
  pii: string[];
  redacted: string;
  classification: "public" | "internal" | "confidential" | "restricted";
}

export function scanPrivacy(text: string): PrivacyScan {
  const secrets = SECRET_PATTERNS.filter((s) => s.pattern.test(text)).map((s) => s.label);
  const pii = PII_PATTERNS.filter((p) => p.pattern.test(text)).map((p) => p.label);

  let redacted = text;
  for (const s of SECRET_PATTERNS) redacted = redacted.replace(new RegExp(s.pattern.source, "g"), "***REDACTED***");
  redacted = redacted
    .replace(/\b\d{3}-\d{2}-\d{4}\b/g, "***-**-****")
    .replace(/\b(?:\d[ -]?){13,16}\b/g, "****-****-****-****")
    .replace(/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g, "***@***.***");

  const classification =
    secrets.length > 0 ? "restricted" : pii.length > 0 ? "confidential" : text.length > 0 ? "internal" : "public";
  return { secrets, pii, redacted, classification };
}

/** Simple in-memory rate limiter: max N requests per window per key */
const buckets = new Map<string, { count: number; resetAt: number }>();
export function rateLimit(key: string, max = 30, windowMs = 60_000): boolean {
  const now = Date.now();
  const b = buckets.get(key);
  if (!b || b.resetAt < now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs });
    return true;
  }
  if (b.count >= max) return false;
  b.count += 1;
  return true;
}

export const SAFETY_FEATURES = [
  { key: "blocked_actions", label: "Blocked Action Registry", description: "Ads, destructive ops, security abuse, financial moves, spam — permanently blocked" },
  { key: "organic_only", label: "Organic Growth Only", description: "No PPC, no paid social, no sponsored content — earned growth only" },
  { key: "approval_gates", label: "Approval Gates", description: "Publishing, sending, deploying and deleting always need a human Approve" },
  { key: "rate_limit", label: "Rate Limiting", description: "30 requests/min per operator — prevents runaway API costs" },
  { key: "content_safety", label: "Content Safety Scanner", description: "Every command scanned for scripts, toxic and malicious patterns" },
  { key: "secrets_scan", label: "Secrets & PII Detection", description: "API keys, tokens, cards and emails detected and redacted" },
  { key: "classification", label: "Data Classification", description: "Auto-tags public / internal / confidential / restricted" },
  { key: "quarantine", label: "Quarantine", description: "Blocked commands are isolated in the audit log for review" },
  { key: "audit_log", label: "Immutable Audit Log", description: "Every check, mission and approval permanently recorded" },
] as const;
