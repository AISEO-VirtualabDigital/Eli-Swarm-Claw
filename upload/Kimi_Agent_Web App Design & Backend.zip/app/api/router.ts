import { authRouter } from "./auth-router";
import { eliRouter } from "./eliRouter";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  eli: eliRouter,
});

export type AppRouter = typeof appRouter;
