import { and, desc, eq, like, or } from "drizzle-orm";
import { analyses, auditLogs, knowledgeEntries, missions, schedules } from "@db/schema";
import { getDb } from "./connection";

// ------------------------------ audit --------------------------------------

export async function logAudit(entry: {
  userId: number;
  event: string;
  category: string;
  detail?: string;
  riskLevel?: string;
}) {
  await getDb()
    .insert(auditLogs)
    .values({
      userId: entry.userId,
      event: entry.event,
      category: entry.category,
      detail: entry.detail ?? "",
      riskLevel: entry.riskLevel ?? "low",
    });
}

export async function listAuditLogs(userId: number, limit = 100) {
  return getDb()
    .select()
    .from(auditLogs)
    .where(eq(auditLogs.userId, userId))
    .orderBy(desc(auditLogs.createdAt))
    .limit(Math.min(limit, 500));
}

// ----------------------------- missions ------------------------------------

export async function createMission(data: {
  userId: number;
  command: string;
  source: "voice" | "typed" | "schedule";
  plan: string;
  status: "preview" | "blocked";
  riskLevel: "low" | "medium" | "high" | "critical";
}) {
  const [{ id }] = await getDb().insert(missions).values(data).$returningId();
  return getDb().query.missions.findFirst({ where: eq(missions.id, id) });
}

export async function listMissions(userId: number, limit = 50) {
  return getDb()
    .select()
    .from(missions)
    .where(eq(missions.userId, userId))
    .orderBy(desc(missions.createdAt))
    .limit(Math.min(limit, 200));
}

export async function getMission(userId: number, id: number) {
  return getDb().query.missions.findFirst({
    where: and(eq(missions.id, id), eq(missions.userId, userId)),
  });
}

export async function updateMissionStatus(
  userId: number,
  id: number,
  status: "approved" | "executed" | "rejected",
  result?: string
) {
  await getDb()
    .update(missions)
    .set({ status, ...(result !== undefined ? { result } : {}) })
    .where(and(eq(missions.id, id), eq(missions.userId, userId)));
  return getMission(userId, id);
}

// ------------------------------- vault -------------------------------------

export async function listKnowledge(userId: number, limit = 100) {
  return getDb()
    .select()
    .from(knowledgeEntries)
    .where(eq(knowledgeEntries.userId, userId))
    .orderBy(desc(knowledgeEntries.createdAt))
    .limit(Math.min(limit, 300));
}

export async function searchKnowledge(userId: number, q: string) {
  const pattern = `%${q}%`;
  return getDb()
    .select()
    .from(knowledgeEntries)
    .where(
      and(
        eq(knowledgeEntries.userId, userId),
        or(like(knowledgeEntries.title, pattern), like(knowledgeEntries.content, pattern), like(knowledgeEntries.tags, pattern))
      )
    )
    .orderBy(desc(knowledgeEntries.createdAt))
    .limit(50);
}

export async function addKnowledge(data: { userId: number; title: string; content: string; tags: string }) {
  const [{ id }] = await getDb().insert(knowledgeEntries).values(data).$returningId();
  return getDb().query.knowledgeEntries.findFirst({ where: eq(knowledgeEntries.id, id) });
}

export async function removeKnowledge(userId: number, id: number) {
  await getDb()
    .delete(knowledgeEntries)
    .where(and(eq(knowledgeEntries.id, id), eq(knowledgeEntries.userId, userId)));
}

// ----------------------------- schedules -----------------------------------

export async function listSchedules(userId: number) {
  return getDb()
    .select()
    .from(schedules)
    .where(eq(schedules.userId, userId))
    .orderBy(desc(schedules.createdAt))
    .limit(100);
}

export async function addSchedule(data: { userId: number; name: string; command: string; cron: string }) {
  const [{ id }] = await getDb().insert(schedules).values(data).$returningId();
  return getDb().query.schedules.findFirst({ where: eq(schedules.id, id) });
}

export async function toggleSchedule(userId: number, id: number) {
  const existing = await getDb().query.schedules.findFirst({
    where: and(eq(schedules.id, id), eq(schedules.userId, userId)),
  });
  if (!existing) return undefined;
  await getDb()
    .update(schedules)
    .set({ enabled: !existing.enabled })
    .where(and(eq(schedules.id, id), eq(schedules.userId, userId)));
  return getDb().query.schedules.findFirst({ where: eq(schedules.id, id) });
}

export async function removeSchedule(userId: number, id: number) {
  await getDb()
    .delete(schedules)
    .where(and(eq(schedules.id, id), eq(schedules.userId, userId)));
}

// ----------------------------- analyses ------------------------------------

export async function saveAnalysis(data: {
  userId: number;
  url: string;
  kind: "url" | "crawl";
  score: number;
  report: string;
}) {
  const [{ id }] = await getDb().insert(analyses).values(data).$returningId();
  return getDb().query.analyses.findFirst({ where: eq(analyses.id, id) });
}

export async function listAnalyses(userId: number, limit = 30) {
  return getDb()
    .select()
    .from(analyses)
    .where(eq(analyses.userId, userId))
    .orderBy(desc(analyses.createdAt))
    .limit(Math.min(limit, 100));
}
