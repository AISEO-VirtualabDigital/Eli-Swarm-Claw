import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  boolean,
  int,
  bigint,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ---------------------------------------------------------------------------
// Eli OS Core tables
// ---------------------------------------------------------------------------

export const missions = mysqlTable("missions", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  command: varchar("command", { length: 1000 }).notNull(),
  source: mysqlEnum("source", ["voice", "typed", "schedule"])
    .default("typed")
    .notNull(),
  plan: text("plan").notNull(), // JSON-encoded mission plan
  status: mysqlEnum("status", [
    "preview",
    "approved",
    "executed",
    "rejected",
    "blocked",
  ])
    .default("preview")
    .notNull(),
  riskLevel: mysqlEnum("riskLevel", ["low", "medium", "high", "critical"])
    .default("low")
    .notNull(),
  result: text("result"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type Mission = typeof missions.$inferSelect;

export const auditLogs = mysqlTable("audit_logs", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  event: varchar("event", { length: 255 }).notNull(),
  category: varchar("category", { length: 64 }).notNull(), // safety | mission | analyzer | vault | schedule | system
  detail: text("detail"),
  riskLevel: varchar("riskLevel", { length: 16 }).default("low").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AuditLog = typeof auditLogs.$inferSelect;

export const knowledgeEntries = mysqlTable("knowledge_entries", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  content: text("content").notNull(),
  tags: varchar("tags", { length: 500 }).default("").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type KnowledgeEntry = typeof knowledgeEntries.$inferSelect;

export const schedules = mysqlTable("schedules", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  command: varchar("command", { length: 1000 }).notNull(),
  cron: varchar("cron", { length: 64 }).notNull(),
  enabled: boolean("enabled").default(true).notNull(),
  lastRunAt: timestamp("lastRunAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Schedule = typeof schedules.$inferSelect;

export const analyses = mysqlTable("analyses", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  url: varchar("url", { length: 1000 }).notNull(),
  kind: mysqlEnum("kind", ["url", "crawl"]).default("url").notNull(),
  score: int("score").default(0).notNull(),
  report: text("report").notNull(), // JSON-encoded analysis report
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Analysis = typeof analyses.$inferSelect;
